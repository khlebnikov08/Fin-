import React, { useState } from 'react';
import {
  StockAsset,
  BondAsset,
  BankDeposit,
  CryptoAsset,
  BusinessOrRealEstate,
  MacroNews,
} from '../../types/game';
import {
  TrendingUp,
  BarChart2,
  FileText,
  Building2,
  Coins,
  ShieldCheck,
  AlertTriangle,
  Plus,
  Minus,
  Sparkles,
  Home,
  Briefcase,
  Flame,
  Rocket,
} from 'lucide-react';
import { sound } from '../../utils/audio';

interface InvestmentsTabProps {
  cash: number;
  stocks: StockAsset[];
  onBuyStock: (stockId: string, count: number) => void;
  onSellStock: (stockId: string, count: number) => void;
  bonds: BondAsset[];
  onBuyBond: (bondId: string, count: number) => void;
  onSellBond: (bondId: string, count: number) => void;
  deposits: BankDeposit[];
  onOpenDeposit: (params: {
    bankName: string;
    bankType: 'STATE_TOP' | 'REGIONAL' | 'NEOBANK';
    interestRate: number;
    termYears: number;
    amount: number;
  }) => void;
  onCloseDepositEarly: (depositId: string) => void;
  crypto: CryptoAsset[];
  onBuyCrypto: (cryptoId: string, rubleAmount: number) => void;
  onSellCrypto: (cryptoId: string, rubleAmount: number) => void;
  businessAssets: BusinessOrRealEstate[];
  onBuyBusinessAsset: (assetId: string) => void;
  year: number;
  keyRate: number;
  currentNews?: MacroNews;
}

export const InvestmentsTab: React.FC<InvestmentsTabProps> = ({
  cash,
  stocks,
  onBuyStock,
  onSellStock,
  bonds,
  onBuyBond,
  onSellBond,
  deposits,
  onOpenDeposit,
  onCloseDepositEarly,
  crypto,
  onBuyCrypto,
  onSellCrypto,
  businessAssets,
  onBuyBusinessAsset,
  year,
  keyRate,
  currentNews,
}) => {
  const [subTab, setSubTab] = useState<'stocks' | 'bonds' | 'deposits' | 'crypto' | 'business'>('stocks');

  // New deposit form state
  const [depositAmount, setDepositAmount] = useState<number>(200000);
  const [depositTerm, setDepositTerm] = useState<number>(2);
  const [selectedBankType, setSelectedBankType] = useState<'STATE_TOP' | 'REGIONAL' | 'NEOBANK'>('STATE_TOP');

  // Calculate deposit rate based on key rate and bank type
  const getBankRate = (type: 'STATE_TOP' | 'REGIONAL' | 'NEOBANK') => {
    if (type === 'STATE_TOP') return keyRate - 0.02; // e.g. 10%
    if (type === 'REGIONAL') return keyRate + 0.015; // e.g. 13.5%
    return keyRate + 0.055; // e.g. 17.5%
  };

  const handleOpenDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cash < depositAmount || depositAmount <= 0) return;
    sound.playCoin();
    const bankName =
      selectedBankType === 'STATE_TOP'
        ? 'Сбер / Госбанк'
        : selectedBankType === 'REGIONAL'
        ? 'Волга-Капитал Банк'
        : 'ИнноВклад Необанк';

    onOpenDeposit({
      bankName,
      bankType: selectedBankType,
      interestRate: getBankRate(selectedBankType),
      termYears: depositTerm,
      amount: depositAmount,
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Subtab Segmented Control */}
      <div className="flex items-center gap-1.5 p-1.5 bg-slate-100 rounded-2xl overflow-x-auto scrollbar-none">
        <button
          onClick={() => {
            sound.playClick();
            setSubTab('stocks');
          }}
          className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-xl transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            subTab === 'stocks'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BarChart2 className="w-4 h-4 text-blue-600" />
          <span>Акции & Дивиденды</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setSubTab('bonds');
          }}
          className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-xl transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            subTab === 'bonds'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileText className="w-4 h-4 text-amber-600" />
          <span>Облигации (Купоны)</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setSubTab('deposits');
          }}
          className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-xl transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            subTab === 'deposits'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-4 h-4 text-emerald-600" />
          <span>Вклады & АСВ</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setSubTab('crypto');
          }}
          className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-xl transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            subTab === 'crypto'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Coins className="w-4 h-4 text-purple-600" />
          <span>Криптовалюта</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setSubTab('business');
          }}
          className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-xl transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            subTab === 'business'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Sparkles className="w-4 h-4 text-teal-600" />
          <span>Бизнес & Недвижимость</span>
        </button>
      </div>

      {/* SUBTAB 1: STOCKS */}
      {subTab === 'stocks' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Рынок акций и дивидендов
              </h3>
              <p className="text-xs text-slate-500">
                Покупка доли в бизнесе: рост стоимости акций + ежегодные дивиденды на баланс
              </p>
            </div>
            <div className="text-xs text-slate-500">
              Баланс: <span className="font-bold text-slate-900 tabular-nums">{cash.toLocaleString('ru-RU')} ₽</span>
            </div>
          </div>

          {/* Current AI Macro News Market Impact Banner */}
          {currentNews && (
            <div
              className={`p-3.5 sm:p-4 rounded-2xl border text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs ${
                currentNews.cycleType === 'CRISIS' || currentNews.cycleType === 'STAGFLATION'
                  ? 'bg-rose-50/80 border-rose-200 text-rose-950'
                  : currentNews.cycleType === 'BOOM' || currentNews.cycleType === 'TECH_RALLY'
                  ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                  : 'bg-purple-50/70 border-purple-200 text-purple-950'
              }`}
            >
              <div className="flex items-start sm:items-center gap-2.5">
                <span className="p-1.5 rounded-lg bg-white shadow-2xs shrink-0 mt-0.5 sm:mt-0">
                  {currentNews.cycleType === 'CRISIS' || currentNews.cycleType === 'STAGFLATION' ? (
                    <Flame className="w-4 h-4 text-rose-600" />
                  ) : currentNews.cycleType === 'BOOM' || currentNews.cycleType === 'TECH_RALLY' ? (
                    <Rocket className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Sparkles className="w-4 h-4 text-purple-600" />
                  )}
                </span>
                <div>
                  <div className="text-[10px] uppercase font-bold tracking-wider opacity-75">
                    Фондовый рынок под влиянием новости ({currentNews.cycleType === 'CRISIS' ? 'Кризис' : currentNews.cycleType === 'BOOM' ? 'Бум' : 'Экономический цикл'})
                  </div>
                  <div className="font-bold text-xs sm:text-sm text-slate-900">
                    {currentNews.headline}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 font-semibold">
                <span className={`px-2.5 py-1 rounded-lg bg-white border shadow-2xs ${
                  currentNews.marketImpact.stockMarketMultiplier >= 1
                    ? 'border-emerald-200 text-emerald-700'
                    : 'border-rose-200 text-rose-700'
                }`}>
                  Индекс акций: {currentNews.marketImpact.stockMarketMultiplier >= 1 ? '+' : ''}
                  {((currentNews.marketImpact.stockMarketMultiplier - 1) * 100).toFixed(0)}%
                </span>
                {currentNews.marketImpact.hitSector && (
                  <span className="px-2.5 py-1 rounded-lg bg-rose-100 text-rose-900 border border-rose-200">
                    Удар по сектору: <strong>{currentNews.marketImpact.hitSector}</strong>
                  </span>
                )}
                {currentNews.marketImpact.favoredSector && (
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-200">
                    В плюсе: <strong>{currentNews.marketImpact.favoredSector}</strong>
                  </span>
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {stocks.map((stock) => {
              const priceDelta = stock.price - stock.prevPrice;
              const percentDelta = stock.prevPrice > 0 ? (priceDelta / stock.prevPrice) * 100 : 0;
              const totalValue = stock.ownedShares * stock.price;
              const dividendPerShare = Math.round(stock.price * stock.dividendYield);
              const expectedDividends = Math.round(totalValue * stock.dividendYield);

              // Portfolio past year gain from this stock
              const portfolioPriceGain = stock.ownedShares * priceDelta;
              const portfolioDividendsGain = stock.ownedShares * dividendPerShare;
              const portfolioTotalGain = portfolioPriceGain + portfolioDividendsGain;

              const isHitByNews = currentNews?.marketImpact.hitSector === stock.sector;
              const isFavoredByNews = currentNews?.marketImpact.favoredSector === stock.sector;

              const canBuy10 = cash >= stock.price * 10;
              const canBuy50 = cash >= stock.price * 50;
              const maxCanBuy = Math.floor(cash / stock.price);

              return (
                <div
                  key={stock.id}
                  className={`bg-white rounded-2xl border p-5 shadow-xs flex flex-col justify-between transition-all ${
                    isHitByNews
                      ? 'border-rose-300 ring-1 ring-rose-200 bg-rose-50/15'
                      : isFavoredByNews
                      ? 'border-emerald-300 ring-1 ring-emerald-200 bg-emerald-50/15'
                      : 'border-slate-200/80'
                  }`}
                >
                  <div>
                    {/* Sector specific news impact alert */}
                    {isHitByNews && (
                      <div className="p-2 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-[11px] font-bold flex items-center gap-1.5 mb-2.5">
                        <Flame className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                        <span>Сектор под ударом текущего кризиса! Котировки снижены.</span>
                      </div>
                    )}
                    {isFavoredByNews && (
                      <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold flex items-center gap-1.5 mb-2.5">
                        <Rocket className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Сектор-бенефициар текущего цикла! Котировки на подъеме.</span>
                      </div>
                    )}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm sm:text-base text-slate-900">
                            {stock.name}
                          </span>
                          <span className="text-xs text-slate-400 font-mono">
                            {stock.sector}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                          {stock.description}
                        </p>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-base font-bold text-slate-900 tabular-nums">
                          {stock.price.toLocaleString('ru-RU')} ₽
                        </div>
                        <div
                          className={`text-xs font-semibold tabular-nums flex items-center justify-end gap-1 ${
                            priceDelta >= 0 ? 'text-emerald-600' : 'text-rose-600'
                          }`}
                        >
                          <span>{priceDelta >= 0 ? '+' : ''}{percentDelta.toFixed(1)}%</span>
                          <span>({priceDelta >= 0 ? '+' : ''}{priceDelta.toLocaleString('ru-RU')} ₽)</span>
                        </div>
                      </div>
                    </div>

                    {/* Stock Metrics */}
                    <div className="grid grid-cols-3 gap-2 py-2.5 my-2.5 bg-slate-50 rounded-xl px-3 text-xs border border-slate-100">
                      <div>
                        <span className="text-slate-400 block text-[10px]">В портфеле</span>
                        <span className="font-bold text-slate-800 tabular-nums">
                          {stock.ownedShares.toLocaleString('ru-RU')} шт.
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Стоимость</span>
                        <span className="font-bold text-slate-800 tabular-nums">
                          {totalValue.toLocaleString('ru-RU')} ₽
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Дивиденды/год</span>
                        <span className="font-bold text-blue-600 tabular-nums">
                          {(stock.dividendYield * 100).toFixed(1)}% (+{dividendPerShare} ₽/шт)
                        </span>
                      </div>
                    </div>

                    {/* Portfolio result indicator if user owns shares */}
                    {stock.ownedShares > 0 && (
                      <div
                        className={`p-2.5 rounded-xl border text-xs mb-3 flex items-center justify-between ${
                          portfolioTotalGain >= 0
                            ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900'
                            : 'bg-rose-50/60 border-rose-200 text-rose-900'
                        }`}
                      >
                        <span className="font-medium">Доход в портфеле за прошлый год:</span>
                        <span className="font-bold tabular-nums">
                          {portfolioTotalGain >= 0 ? '+' : ''}
                          {portfolioTotalGain.toLocaleString('ru-RU')} ₽
                          <span className="font-normal text-[11px] ml-1 opacity-80">
                            ({portfolioPriceGain >= 0 ? '+' : ''}{portfolioPriceGain.toLocaleString('ru-RU')} ₽ рост + {portfolioDividendsGain.toLocaleString('ru-RU')} ₽ див.)
                          </span>
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Buy / Sell buttons */}
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          sound.playCoin();
                          onBuyStock(stock.id, 10);
                        }}
                        disabled={!canBuy10}
                        className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-colors ${
                          canBuy10
                            ? 'bg-slate-900 hover:bg-slate-800 text-white'
                            : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                        }`}
                      >
                        +10 шт ({(stock.price * 10).toLocaleString('ru-RU')} ₽)
                      </button>

                      {maxCanBuy >= 50 && (
                        <button
                          onClick={() => {
                            sound.playCoin();
                            onBuyStock(stock.id, 50);
                          }}
                          className="py-1.5 px-2.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors"
                          title="Купить 50 штук"
                        >
                          +50 шт
                        </button>
                      )}

                      {maxCanBuy > 10 && (
                        <button
                          onClick={() => {
                            sound.playCoin();
                            onBuyStock(stock.id, maxCanBuy);
                          }}
                          className="py-1.5 px-2.5 rounded-lg text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 transition-colors"
                          title={`Купить максимум (${maxCanBuy} шт)`}
                        >
                          Макс ({maxCanBuy} шт)
                        </button>
                      )}
                    </div>

                    {stock.ownedShares > 0 && (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            sound.playCoin();
                            onSellStock(stock.id, Math.min(10, stock.ownedShares));
                          }}
                          className="flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                        >
                          -10 шт
                        </button>

                        {stock.ownedShares >= 50 && (
                          <button
                            onClick={() => {
                              sound.playCoin();
                              onSellStock(stock.id, 50);
                            }}
                            className="py-1.5 px-2.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                          >
                            -50 шт
                          </button>
                        )}

                        <button
                          onClick={() => {
                            sound.playCoin();
                            onSellStock(stock.id, stock.ownedShares);
                          }}
                          className="py-1.5 px-2.5 rounded-lg text-xs font-semibold bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 transition-colors"
                        >
                          Продать всё ({stock.ownedShares} шт)
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUBTAB 2: BONDS */}
      {subTab === 'bonds' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Облигации (Займы государству и компаниям)
              </h3>
              <p className="text-xs text-slate-500">
                Каждый ход выплачивают гарантированный купон. Номинал облигации: 1 000 ₽.
              </p>
            </div>
            <div className="text-xs text-slate-500">
              Баланс: <span className="font-bold text-slate-900 tabular-nums">{cash.toLocaleString('ru-RU')} ₽</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {bonds.map((bond) => {
              const totalVal = bond.ownedCount * bond.faceValue;
              const annualCoupon = Math.round(totalVal * bond.couponRate);

              return (
                <div
                  key={bond.id}
                  className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-sm text-slate-900">{bond.name}</span>
                      <span className="text-xs font-bold text-amber-600 tabular-nums">
                        {(bond.couponRate * 100).toFixed(1)}% купон
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 mb-3">{bond.riskText}</p>

                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-1.5 text-xs mb-4">
                      <div className="flex justify-between">
                        <span className="text-slate-500">В портфеле:</span>
                        <span className="font-bold text-slate-800 tabular-nums">{bond.ownedCount} шт.</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Сумма вложений:</span>
                        <span className="font-bold text-slate-800 tabular-nums">{totalVal.toLocaleString('ru-RU')} ₽</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Купонный доход/год:</span>
                        <span className="font-bold text-emerald-600 tabular-nums">+{annualCoupon.toLocaleString('ru-RU')} ₽</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => {
                        sound.playCoin();
                        onBuyBond(bond.id, 50);
                      }}
                      disabled={cash < 50 * bond.faceValue}
                      className={`py-2 px-2 rounded-xl text-xs font-semibold transition-colors ${
                        cash >= 50 * bond.faceValue
                          ? 'bg-slate-900 hover:bg-slate-800 text-white'
                          : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      Купить 50 шт (50k ₽)
                    </button>

                    <button
                      onClick={() => {
                        sound.playCoin();
                        onSellBond(bond.id, 50);
                      }}
                      disabled={bond.ownedCount < 50}
                      className={`py-2 px-2 rounded-xl text-xs font-semibold transition-colors ${
                        bond.ownedCount >= 50
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                          : 'bg-slate-50 text-slate-300 cursor-not-allowed'
                      }`}
                    >
                      Продать 50 шт
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUBTAB 3: DEPOSITS & ASV */}
      {subTab === 'deposits' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Банковские вклады и Система Страхования (АСВ)
              </h3>
              <p className="text-xs text-slate-500">
                Защита государством до 1 400 000 ₽ на банк. Проценты капитализируются раз в год.
              </p>
            </div>
          </div>

          {/* Form to open a new deposit */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-xs">
            <h4 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-600" />
              <span>Открыть новый банковский вклад</span>
            </h4>

            <form onSubmit={handleOpenDepositSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Bank Type */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Выберите банк</label>
                  <select
                    value={selectedBankType}
                    onChange={(e) => setSelectedBankType(e.target.value as 'STATE_TOP' | 'REGIONAL' | 'NEOBANK')}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-slate-900"
                  >
                    <option value="STATE_TOP">Сбер / Госбанк ({(getBankRate('STATE_TOP') * 100).toFixed(1)}% годовых, Риск: 0%)</option>
                    <option value="REGIONAL">Волга-Банк ({(getBankRate('REGIONAL') * 100).toFixed(1)}% годовых, Риск: 3%)</option>
                    <option value="NEOBANK">ИнноВклад Необанк ({(getBankRate('NEOBANK') * 100).toFixed(1)}% годовых, Риск: 8%)</option>
                  </select>
                </div>

                {/* Term */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Срок вклада (лет)</label>
                  <select
                    value={depositTerm}
                    onChange={(e) => setDepositTerm(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-slate-900"
                  >
                    <option value={1}>1 год</option>
                    <option value={2}>2 года</option>
                    <option value={3}>3 года</option>
                    <option value={5}>5 лет</option>
                  </select>
                </div>

                {/* Amount */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Сумма вклада (₽)</label>
                  <input
                    type="number"
                    min={10000}
                    max={cash}
                    step={50000}
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-slate-900 tabular-nums"
                  />
                </div>
              </div>

              {/* ASV Warning / Info Banner */}
              <div className="p-3 bg-blue-50 border border-blue-100 rounded-xl text-xs text-blue-900 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold block">Страхование вкладов (АСВ)</span>
                  <span>
                    В случае отзыва лицензии или банкротства банка государство возмещает до 1 400 000 рублей.
                    {depositAmount > 1400000 && (
                      <span className="text-amber-700 font-semibold block mt-0.5">
                        Внимание: сумма выше 1,4 млн ₽ не защищена страховкой АСВ!
                      </span>
                    )}
                  </span>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={cash < depositAmount || depositAmount <= 0}
                  className={`py-2 px-5 rounded-xl text-xs font-semibold transition-colors ${
                    cash >= depositAmount && depositAmount > 0
                      ? 'bg-slate-900 hover:bg-slate-800 text-white'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  Открыть вклад на {depositAmount.toLocaleString('ru-RU')} ₽
                </button>
              </div>
            </form>
          </div>

          {/* Active Deposits Table */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
            <h4 className="text-sm font-bold text-slate-900 mb-3">Действующие вклады</h4>
            {deposits.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                У вас нет активных вкладов.
              </div>
            ) : (
              <div className="space-y-3">
                {deposits.map((dep) => {
                  const yearsPassed = year - dep.startYear;
                  const yearsRemaining = Math.max(0, dep.termYears - yearsPassed);

                  return (
                    <div
                      key={dep.id}
                      className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">{dep.bankName}</span>
                          <span className="text-emerald-700 font-semibold">
                            {(dep.interestRate * 100).toFixed(1)}% годовых
                          </span>
                        </div>
                        <div className="text-slate-500 mt-1">
                          Начальная сумма: {dep.principal.toLocaleString('ru-RU')} ₽ ·
                          Осталось: {yearsRemaining} {yearsRemaining === 1 ? 'год' : 'года/лет'}
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="text-slate-400 block text-[10px]">Текущий баланс</span>
                          <span className="font-bold text-slate-900 tabular-nums">
                            {Math.round(dep.currentAmount).toLocaleString('ru-RU')} ₽
                          </span>
                        </div>

                        <button
                          onClick={() => {
                            if (confirm('При досрочном закрытии начисленные проценты сгорят. Закрыть?')) {
                              sound.playWarning();
                              onCloseDepositEarly(dep.id);
                            }
                          }}
                          className="px-2.5 py-1.5 bg-slate-200 hover:bg-rose-100 text-slate-700 hover:text-rose-700 rounded-lg font-medium text-[11px] transition-colors"
                        >
                          Закрыть досрочно
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 4: CRYPTO */}
      {subTab === 'crypto' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Криптовалютный рынок
              </h3>
              <p className="text-xs text-slate-500">
                Колоссальная волатильность: возможность заработать в 10 раз или потерять почти всё
              </p>
            </div>
            <div className="text-xs text-slate-500">
              Баланс: <span className="font-bold text-slate-900 tabular-nums">{cash.toLocaleString('ru-RU')} ₽</span>
            </div>
          </div>

          {currentNews && (
            <div className="p-3.5 bg-purple-50/70 border border-purple-200 rounded-2xl text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs">
              <div className="flex items-center gap-2 text-purple-950">
                <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
                <span>
                  <strong>ИИ-макрофон для крипты:</strong> {currentNews.headline}
                </span>
              </div>
              <span
                className={`font-bold tabular-nums px-2.5 py-0.5 rounded-md bg-white border shrink-0 ${
                  currentNews.marketImpact.cryptoMultiplier >= 1
                    ? 'border-purple-200 text-purple-700'
                    : 'border-rose-200 text-rose-700'
                }`}
              >
                Влияние новости: {currentNews.marketImpact.cryptoMultiplier >= 1 ? '+' : ''}
                {((currentNews.marketImpact.cryptoMultiplier - 1) * 100).toFixed(0)}%
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {crypto.map((coin) => {
              const priceDelta = coin.price - coin.prevPrice;
              const percentDelta = coin.prevPrice > 0 ? (priceDelta / coin.prevPrice) * 100 : 0;
              const totalValRub = Math.round(coin.ownedAmount * coin.price);

              return (
                <div
                  key={coin.id}
                  className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-base text-slate-900">{coin.name}</span>
                        <span className="text-xs text-slate-400 font-mono">({coin.symbol})</span>
                      </div>
                      <div className="text-right">
                        <div className="text-base font-bold text-slate-900 tabular-nums">
                          {coin.price.toLocaleString('ru-RU')} ₽
                        </div>
                        <div
                          className={`text-xs font-semibold tabular-nums ${
                            priceDelta >= 0 ? 'text-emerald-600' : 'text-rose-600'
                          }`}
                        >
                          {priceDelta >= 0 ? '+' : ''}
                          {percentDelta.toFixed(1)}%
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 my-3 text-xs space-y-1">
                      <div className="flex justify-between">
                        <span className="text-slate-500">На балансе:</span>
                        <span className="font-bold text-slate-800 tabular-nums">
                          {coin.ownedAmount.toFixed(4)} {coin.symbol}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Эквивалент в рублях:</span>
                        <span className="font-bold text-purple-700 tabular-nums">
                          {totalValRub.toLocaleString('ru-RU')} ₽
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => {
                        sound.playCoin();
                        onBuyCrypto(coin.id, 100000);
                      }}
                      disabled={cash < 100000}
                      className={`py-2 px-3 rounded-xl text-xs font-semibold transition-colors ${
                        cash >= 100000
                          ? 'bg-slate-900 hover:bg-slate-800 text-white'
                          : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      Купить на 100 000 ₽
                    </button>

                    <button
                      onClick={() => {
                        sound.playCoin();
                        onSellCrypto(coin.id, 100000);
                      }}
                      disabled={totalValRub < 100000}
                      className={`py-2 px-3 rounded-xl text-xs font-semibold transition-colors ${
                        totalValRub >= 100000
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                          : 'bg-slate-50 text-slate-300 cursor-not-allowed'
                      }`}
                    >
                      Продать на 100 000 ₽
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUBTAB 5: REAL ESTATE & BUSINESS */}
      {subTab === 'business' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Недвижимость, Бизнес и Защитные активы
              </h3>
              <p className="text-xs text-slate-500">
                Капитальные вложения с ежегодной арендной доходностью и прибылью
              </p>
            </div>
            <div className="text-xs text-slate-500">
              Баланс: <span className="font-bold text-slate-900 tabular-nums">{cash.toLocaleString('ru-RU')} ₽</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {businessAssets.map((asset) => {
              const annualIncome = Math.round(asset.cost * asset.annualIncomeRate);

              return (
                <div
                  key={asset.id}
                  className={`bg-white rounded-2xl border p-5 shadow-xs flex flex-col justify-between transition-all ${
                    asset.owned
                      ? 'border-emerald-300 bg-emerald-50/20'
                      : 'border-slate-200/80 hover:border-slate-300'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <span className="font-bold text-sm sm:text-base text-slate-900 block">
                          {asset.title}
                        </span>
                        <span className="text-xs text-emerald-700 font-semibold">
                          +{(asset.annualIncomeRate * 100).toFixed(0)}% годовой доходности
                        </span>
                      </div>
                      <span className="text-sm font-bold text-slate-900 tabular-nums shrink-0">
                        {asset.cost.toLocaleString('ru-RU')} ₽
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 mb-3 leading-relaxed">
                      {asset.description}
                    </p>

                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-1.5 text-xs mb-4">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Годовой доход:</span>
                        <span className="font-bold text-emerald-600 tabular-nums">
                          +{annualIncome.toLocaleString('ru-RU')} ₽ / год
                        </span>
                      </div>
                      {asset.maintenanceCost > 0 && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Обслуживание/налоги:</span>
                          <span className="font-medium text-rose-600 tabular-nums">
                            -{asset.maintenanceCost.toLocaleString('ru-RU')} ₽ / год
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    {asset.owned ? (
                      <div className="w-full py-2 bg-emerald-100/70 text-emerald-800 font-bold text-xs rounded-xl text-center">
                        Актив в собственности
                      </div>
                    ) : (
                      <button
                        onClick={() => {
                          sound.playJoy();
                          onBuyBusinessAsset(asset.id);
                        }}
                        disabled={cash < asset.cost}
                        className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition-colors ${
                          cash >= asset.cost
                            ? 'bg-slate-900 hover:bg-slate-800 text-white'
                            : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                        }`}
                      >
                        Приобрести за {asset.cost.toLocaleString('ru-RU')} ₽
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
