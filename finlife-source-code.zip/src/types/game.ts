// Types for Financial Life Simulator

export type GameMode = '10_YEARS' | 'GOAL' | 'SANDBOX';

export interface LifeGoal {
  id: string;
  title: string;
  description: string;
  targetCapital: number;
  minJoy: number;
  custom?: boolean;
  requiredAssets?: {
    hasApartment?: boolean;
    hasBusiness?: boolean;
    passiveIncomeTarget?: number;
  };
}

export interface CharacterPreset {
  id: string;
  name: string;
  role: string;
  description: string;
  initialSalary: number; // annual
  initialCash: number;
  initialJoy: number;
  avatarIcon: string;
}

export interface StockAsset {
  id: string;
  name: string;
  ticker: string;
  sector: string;
  description: string;
  price: number;
  prevPrice: number;
  dividendYield: number; // e.g. 0.08 for 8%
  risk: 'low' | 'medium' | 'high';
  isBankrupt?: boolean;
  ownedShares: number;
  history: number[];
}

export interface BondAsset {
  id: string;
  name: string;
  type: 'OFZ' | 'CORP' | 'HIGH_YIELD';
  couponRate: number; // annual percentage e.g. 0.12
  faceValue: number; // 1000 ₽ per bond
  riskText: string;
  defaultChance: number; // chance to default
  ownedCount: number;
}

export interface BankDeposit {
  id: string;
  bankName: string;
  bankType: 'STATE_TOP' | 'REGIONAL' | 'NEOBANK';
  interestRate: number;
  termYears: number;
  startYear: number;
  principal: number;
  currentAmount: number;
  isInsuredAsv: boolean; // up to 1.4m
}

export interface CryptoAsset {
  id: string;
  name: string;
  symbol: string;
  price: number;
  prevPrice: number;
  volatility: number;
  ownedAmount: number;
  history: number[];
}

export interface BusinessOrRealEstate {
  id: string;
  title: string;
  type: 'REAL_ESTATE' | 'BUSINESS' | 'GOLD';
  cost: number;
  annualIncomeRate: number; // percentage of cost
  owned: boolean;
  description: string;
  maintenanceCost: number; // per year
}

export interface Loan {
  id: string;
  bankName: string;
  totalAmount: number;
  remainingDebt: number;
  annualInterestRate: number;
  annualPayment: number;
  durationYears: number;
  yearsRemaining: number;
}

export interface CreditCard {
  limit: number;
  usedAmount: number;
  gracePeriodYearsRemaining: number; // 1 = inside grace period, 0 = overdue, interest applied
  interestRate: number; // e.g. 0.28
  penaltyRate: number; // e.g. 0.10
  isOverdue: boolean;
}

export interface DebitCard {
  active: boolean;
  name: string;
  cashbackRate: number; // e.g. 0.03 for 3%
  annualFee: number;
  benefitDescription: string;
}

export interface InsurancePolicy {
  type: 'HEALTH_DMS' | 'HOME' | 'CAR_CASCO';
  name: string;
  annualCost: number;
  active: boolean;
  description: string;
}

export interface EducationTier {
  id: string;
  name: string;
  cost: number;
  salaryBonusMultiplier: number; // e.g. 0.20 (+20%)
  joyBonus: number;
  description: string;
  completed: boolean;
}

export interface OptionalExpense {
  id: string;
  title: string;
  cost: number;
  joyDeltaIfAccepted: number;
  joyDeltaIfDeclined: number;
  permanentAnnualCostDelta?: number; // e.g. car maintenance
  description: string;
  category: 'LEISURE' | 'PURCHASE' | 'LUXURY' | 'FAMILY';
  isOneTimeAssetPurchase?: 'CAR' | 'APARTMENT';
}

export interface EventChoice {
  id: string;
  label: string;
  cashDelta: number;
  joyDelta: number;
  description?: string;
}

export interface GameRandomEvent {
  id: string;
  title: string;
  description: string;
  cashDelta: number;
  joyDelta: number;
  coveredByInsurance?: 'HEALTH_DMS' | 'HOME' | 'CAR_CASCO';
  insuranceAvoidedLoss?: number;
  requiresCar?: boolean;
  requiresApartment?: boolean;
  iconType: 'good' | 'bad' | 'neutral';
  isAiGenerated?: boolean;
  choices?: EventChoice[];
}

export interface MacroNews {
  id: string;
  headline: string;
  summary: string;
  inflationDelta: number;
  keyRateDelta: number;
  durationYears?: number; // 1, 2, or 3 years
  yearsRemaining?: number;
  isAiGenerated?: boolean;
  cycleType?: 'CRISIS' | 'BOOM' | 'STAGFLATION' | 'TECH_RALLY' | 'STANDARD';
  gameplayAdvice?: string;
  marketImpact: {
    stockMarketMultiplier: number;
    cryptoMultiplier: number;
    favoredSector?: string;
    hitSector?: string;
    salaryMultiplier?: number;
    businessMultiplier?: number;
  };
}

export interface TurnReport {
  year: number;
  salaryIncome: number;
  businessIncome: number;
  dividendsEarned: number;
  couponsEarned: number;
  depositInterestEarned: number;
  cashbackEarned: number;
  taxDeductionsEarned: number;
  mandatoryExpensesPaid: number;
  optionalExpensesPaid: number;
  insurancePaid: number;
  cardFeesPaid: number;
  loanPaymentsPaid: number;
  creditCardInterestPaid: number;
  eventsSummary: string[];
  netCashDelta: number;
  netWorthDelta: number;
  joyDelta: number;
}

export interface YearHistoryPoint {
  year: number;
  netWorth: number;
  cash: number;
  invested: number;
  joy: number;
  passiveIncome: number;
}

export interface LeaderboardEntry {
  id: string;
  playerName: string;
  mode: GameMode;
  goalTitle: string;
  finalCapital: number;
  finalJoy: number;
  yearsTaken: number;
  isVictorious: boolean;
  timestamp: number;
}
