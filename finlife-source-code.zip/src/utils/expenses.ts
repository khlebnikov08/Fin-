// Mandatory Expenses and Tax Calculator

export interface MandatoryExpensesBreakdown {
  total: number;
  incomeTax: number;       // Подоходный налог (НДФЛ 13%)
  livingCosts: number;     // Базовое питание, быт, коммуналка
  housingCosts: number;    // Аренда или содержание своего жилья
  transportCosts: number;  // Транспорт или авто
  cardFees: number;        // Обслуживание карт
}

export function calculateMandatoryExpensesBreakdown(params: {
  annualSalary: number;
  baseLivingFloor: number;
  hasApartment: boolean;
  hasCar: boolean;
  debitCardActive: boolean;
  inflationMultiplier: number;
}): MandatoryExpensesBreakdown {
  const {
    annualSalary,
    baseLivingFloor,
    hasApartment,
    hasCar,
    debitCardActive,
    inflationMultiplier,
  } = params;

  // 1. Income Tax (НДФЛ 13% в РФ)
  const incomeTax = Math.round(annualSalary * 0.13);

  // 2. Base living costs (food, household, clothing, health routines)
  // Indexed to inflation + moderate lifestyle scaling with career growth (+5% of salary)
  const livingCosts = Math.round(
    (baseLivingFloor * inflationMultiplier) + (annualSalary * 0.05)
  );

  // 3. Housing costs
  // If player owns an apartment: rent is 0, only maintenance / property tax (~60k indexed)
  // If renting: market rent ~280k indexed
  const housingCosts = hasApartment
    ? Math.round(60000 * inflationMultiplier)
    : Math.round(280000 * inflationMultiplier);

  // 4. Transport costs
  // If player owns a car: gas + maintenance + insurance ~140k indexed
  // If public transit: ~40k indexed
  const transportCosts = hasCar
    ? Math.round(140000 * inflationMultiplier)
    : Math.round(40000 * inflationMultiplier);

  // 5. Banking card annual fees
  const cardFees = debitCardActive ? 1500 : 0;

  const total = incomeTax + livingCosts + housingCosts + transportCosts + cardFees;

  return {
    total,
    incomeTax,
    livingCosts,
    housingCosts,
    transportCosts,
    cardFees,
  };
}
