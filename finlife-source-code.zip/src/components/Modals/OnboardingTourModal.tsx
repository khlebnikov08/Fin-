import React, { useState } from 'react';
import {
  Sparkles,
  ChevronRight,
  ChevronLeft,
  X,
  Target,
  Heart,
  TrendingUp,
  Receipt,
  Landmark,
  GraduationCap,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';
import { sound } from '../../utils/audio';

interface OnboardingTourModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TourStep {
  title: string;
  badge: string;
  icon: React.ReactNode;
  subtitle: string;
  points: { title: string; desc: string }[];
  highlightTip?: string;
}

export const OnboardingTourModal: React.FC<OnboardingTourModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const steps: TourStep[] = [
    {
      title: 'Добро пожаловать в «ФинПуть»',
      badge: 'Шаг 1: Философия игры',
      icon: <Sparkles className="w-6 h-6 text-emerald-600" />,
      subtitle: 'Симулятор вашей финансовой жизни, где деньги служат счастью',
      points: [
        {
          title: 'Баланс капитала и радости',
          desc: 'В отличие от обычных симуляторов, здесь недостаточно просто копить миллионы. Чтобы победить, держите уровень Радости не ниже 80 пунктов!',
        },
        {
          title: 'Опасность выгорания',
          desc: 'Если радость упадет ниже 30, ваш доход снизится на 20% из-за выгорания. Радуйте себя отпусками, покупками и подарками.',
        },
        {
          title: 'Свобода выбора цели',
          desc: 'Вы можете пройти классическую 10-летку, накопить на квартиру, построить бизнес-империю или играть бесконечно в песочнице.',
        },
      ],
      highlightTip: 'Совет: не жалейте разумных средств на необязательные радости года — они восстанавливают шкалу счастья!',
    },
    {
      title: 'Строка статуса и Панель игрока',
      badge: 'Шаг 2: Где что находится',
      icon: <Target className="w-6 h-6 text-blue-600" />,
      subtitle: 'Вся важнейшая информация всегда видна в верхней строке экрана',
      points: [
        {
          title: 'Свободные деньги',
          desc: 'Ваш текущий остаток на счете. Именно из него оплачиваются расходы, покупаются акции и открываются вклады.',
        },
        {
          title: 'Общий капитал (Net Worth)',
          desc: 'Сумма всех ваших активов (наличные + акции + облигации + вклады + бизнес) за вычетом долгов по кредитам.',
        },
        {
          title: 'Шкала Радости (0–100)',
          desc: 'Отражает ваше душевное состояние. Чем выше шкала, тем продуктивнее карьера и выше шансы на победу.',
        },
        {
          title: 'Индикатор цели',
          desc: 'Нажмите на название цели в строке статуса, чтобы увидеть подробный прогресс и необходимые условия.',
        },
      ],
      highlightTip: 'Строка статуса компактна и не загромождает экран при переключении между вкладками.',
    },
    {
      title: 'Годовой цикл и Бюджет года',
      badge: 'Шаг 3: Механика хода (1 год)',
      icon: <Receipt className="w-6 h-6 text-amber-600" />,
      subtitle: 'Каждый клик кнопки «Завершить год» продвигает вашу жизнь на 1 год вперед',
      points: [
        {
          title: 'Доход и зарплата',
          desc: 'В начале года вам начисляется зарплата и дивиденды от накопленных активов.',
        },
        {
          title: 'Обязательный платеж за год',
          desc: 'Состоит из налога НДФЛ 13%, базового питания и ЖКХ, аренды (или содержания своего жилья) и транспорта. Его нужно обязательно оплатить до перехода к следующему ходу.',
        },
        {
          title: 'Радости и желания года',
          desc: 'Каждый год вам предлагают интересные события (путешествия, хобби, гаджеты). Выбирайте, на что согласиться, а что пропустить.',
        },
        {
          title: 'Страхование рисков',
          desc: 'Полис действует ровно 1 год и спасает от крупных денежных потерь при непредвиденных кризисах.',
        },
      ],
      highlightTip: 'Если купить собственную квартиру, обязательные расходы снизятся — ведь вам больше не нужно платить за аренду!',
    },
    {
      title: 'Инвестиции: приумножение капитала',
      badge: 'Шаг 4: Рынок и доходность',
      icon: <TrendingUp className="w-6 h-6 text-purple-600" />,
      subtitle: 'Заставьте деньги работать на вас и приносить пассивный доход',
      points: [
        {
          title: '8 различных акций компаний',
          desc: 'IT, банки, нефть, ритейл, металлургия, девелопмент, e-commerce и биотех. В карточке акции показано, сколько она принесла в рублях за прошедший год!',
        },
        {
          title: 'Облигации ОФЗ и корпоративные бонды',
          desc: 'Надежный источник фиксированных купонных выплат каждый год прямо на ваш счет.',
        },
        {
          title: 'Банковские вклады с защитой АСВ',
          desc: 'Вклады под ставку ЦБ с государственной страховкой до 1.4 млн рублей.',
        },
        {
          title: 'Криптовалюта и Недвижимость/Бизнес',
          desc: 'Высокодоходные активы, генерирующие высокий денежный поток.',
        },
      ],
      highlightTip: 'Дивиденды и купоны поступают каждый год автоматически и пополняют ваши свободные средства.',
    },
    {
      title: 'Банки, Кредитный рычаг и Образование',
      badge: 'Шаг 5: Прорывной рост',
      icon: <Landmark className="w-6 h-6 text-teal-600" />,
      subtitle: 'Инструменты ускорения и инвестиции в свой человеческий капитал',
      points: [
        {
          title: 'Зачем брать кредит: Финансовый рычаг',
          desc: 'Кредит на 3–5 лет под 14% выгоден, если вложить деньги в бизнес или образование с доходностью 30–60%. Разница ставок — ваша чистая прибыль!',
        },
        {
          title: 'Кредитная карта с грейс-периодом',
          desc: 'Позволяет перехватить деньги на 1 год без процентов, но не забудьте вернуть долг вовремя, иначе начислятся штрафы.',
        },
        {
          title: 'Инвестиции в образование',
          desc: 'Проф. курсы, второе высшее и MBA удваивают вашу годовую зарплату, а государство возвращает 13% налоговым вычетом!',
        },
      ],
      highlightTip: 'Вы готовы! Принимайте взвешенные финансовые решения и достигайте великих целей!',
    },
  ];

  const current = steps[currentStep];
  const isLast = currentStep === steps.length - 1;

  const handleNext = () => {
    sound.playClick();
    if (isLast) {
      localStorage.setItem('finlife_tour_completed', 'true');
      onClose();
    } else {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    sound.playClick();
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleSkip = () => {
    sound.playClick();
    localStorage.setItem('finlife_tour_completed', 'true');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-xl w-full p-6 sm:p-8 space-y-6 flex flex-col justify-between">
        {/* Header */}
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-700">
                {current.badge}
              </span>
              <span className="text-xs text-slate-400">
                {currentStep + 1} из {steps.length}
              </span>
            </div>

            <button
              onClick={handleSkip}
              className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors"
              title="Закрыть тур"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Step dots */}
          <div className="flex items-center gap-1.5 pt-3">
            {steps.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  sound.playClick();
                  setCurrentStep(idx);
                }}
                className={`h-1.5 rounded-full transition-all ${
                  idx === currentStep
                    ? 'w-8 bg-slate-900'
                    : idx < currentStep
                    ? 'w-4 bg-emerald-500'
                    : 'w-2 bg-slate-200'
                }`}
                aria-label={`Шаг ${idx + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Content Body */}
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 shrink-0">
              {current.icon}
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 font-heading">
                {current.title}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {current.subtitle}
              </p>
            </div>
          </div>

          {/* Points list */}
          <div className="space-y-2.5 pt-2">
            {current.points.map((pt, i) => (
              <div
                key={i}
                className="p-3 rounded-xl bg-slate-50/70 border border-slate-100 text-xs flex items-start gap-2.5"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-800 block">{pt.title}</span>
                  <span className="text-slate-600 leading-relaxed mt-0.5 block">{pt.desc}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Highlight Tip */}
          {current.highlightTip && (
            <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-200 text-xs text-emerald-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-medium">{current.highlightTip}</span>
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <button
            onClick={handleSkip}
            className="text-xs font-semibold text-slate-400 hover:text-slate-700 transition-colors"
          >
            Пропустить тур
          </button>

          <div className="flex items-center gap-2">
            {currentStep > 0 && (
              <button
                onClick={handlePrev}
                className="py-2.5 px-4 rounded-xl border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors flex items-center gap-1"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Назад</span>
              </button>
            )}

            <button
              onClick={handleNext}
              className="py-2.5 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors flex items-center gap-1.5"
            >
              <span>{isLast ? 'Начать игру!' : 'Далее'}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
