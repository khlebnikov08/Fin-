import React from 'react';
import { TurnReport, MacroNews } from '../types/game';
import { ArrowUpRight, ArrowDownRight, Sparkles, TrendingUp, Briefcase, Landmark, ShieldCheck, ChevronRight, Flame, Rocket } from 'lucide-react';
import { sound } from '../utils/audio';

interface TurnSummaryModalProps {
  report: TurnReport | null;
  isOpen: boolean;
  onClose: () => void;
  inflationRate: number;
  currentNews?: MacroNews | null;
}

export const TurnSummaryModal: React.FC<TurnSummaryModalProps> = ({
  report,
  isOpen,
  onClose,
  inflationRate,
  currentNews,
}) => {
  if (!isOpen || !report) return null;

  const totalIncome =
    report.salaryIncome +
    report.businessIncome +
    report.dividendsEarned +
    report.couponsEarned +
    report.depositInterestEarned +
    report.cashbackEarned +
    report.taxDeductionsEarned;

  const totalExpenses =
    report.mandatoryExpensesPaid +
    report.optionalExpensesPaid +
    report.insurancePaid +
    report.cardFeesPaid +
    report.loanPaymentsPaid +
    report.creditCardInterestPaid;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span>Годовой финансовый отчет</span>
              <span aria-hidden="true">·</span>
              <span className="font-semibold text-slate-800">Итоги года {report.year}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-heading mt-0.5">
              Сводка изменений за год
            </h2>
          </div>
          <div className="text-right">
            <span className="text-xs text-slate-500 block">Инфляция за год</span>
            <span className="text-sm font-bold text-amber-600 tabular-nums">
              +{(inflationRate * 100).toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Highlight Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-100">
            <span className="text-xs text-emerald-800 font-medium flex items-center gap-1">
              <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600" />
              Всего доходов
            </span>
            <div className="text-lg font-bold text-emerald-900 mt-1 tabular-nums">
              +{totalIncome.toLocaleString('ru-RU')} ₽
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/70">
            <span className="text-xs text-slate-600 font-medium flex items-center gap-1">
              <ArrowDownRight className="w-3.5 h-3.5 text-rose-500" />
              Всего расходов
            </span>
            <div className="text-lg font-bold text-slate-900 mt-1 tabular-nums">
              -{totalExpenses.toLocaleString('ru-RU')} ₽
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-teal-50/70 border border-teal-100">
            <span className="text-xs text-teal-800 font-medium flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-teal-600" />
              Чистый денежный поток
            </span>
            <div
              className={`text-lg font-bold mt-1 tabular-nums ${
                report.netCashDelta >= 0 ? 'text-teal-900' : 'text-rose-700'
              }`}
            >
              {report.netCashDelta >= 0 ? '+' : ''}
              {report.netCashDelta.toLocaleString('ru-RU')} ₽
            </div>
          </div>
        </div>

        {/* Detailed Incomes Breakdown */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Доходы и инвестиционная отдача
          </h3>
          <div className="bg-slate-50/80 rounded-2xl p-4 border border-slate-100 space-y-2.5 text-xs sm:text-sm">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-slate-600">
                <Briefcase className="w-4 h-4 text-slate-400" />
                Заработная плата
              </span>
              <span className="font-semibold text-slate-900 tabular-nums">
                +{report.salaryIncome.toLocaleString('ru-RU')} ₽
              </span>
            </div>

            {report.businessIncome > 0 && (
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-600">
                  <Sparkles className="w-4 h-4 text-emerald-500" />
                  Прибыль бизнеса & Аренда
                </span>
                <span className="font-semibold text-emerald-600 tabular-nums">
                  +{report.businessIncome.toLocaleString('ru-RU')} ₽
                </span>
              </div>
            )}

            {report.dividendsEarned > 0 && (
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-600">
                  <TrendingUp className="w-4 h-4 text-blue-500" />
                  Дивиденды по акциям
                </span>
                <span className="font-semibold text-blue-600 tabular-nums">
                  +{report.dividendsEarned.toLocaleString('ru-RU')} ₽
                </span>
              </div>
            )}

            {report.couponsEarned > 0 && (
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-600">
                  <Landmark className="w-4 h-4 text-amber-500" />
                  Купоны по облигациям
                </span>
                <span className="font-semibold text-amber-600 tabular-nums">
                  +{report.couponsEarned.toLocaleString('ru-RU')} ₽
                </span>
              </div>
            )}

            {report.depositInterestEarned > 0 && (
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-600">
                  <Landmark className="w-4 h-4 text-teal-500" />
                  Проценты по вкладам
                </span>
                <span className="font-semibold text-teal-600 tabular-nums">
                  +{report.depositInterestEarned.toLocaleString('ru-RU')} ₽
                </span>
              </div>
            )}

            {report.cashbackEarned > 0 && (
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-600">
                  <Sparkles className="w-4 h-4 text-purple-500" />
                  Кэшбэк по дебетовой карте
                </span>
                <span className="font-semibold text-purple-600 tabular-nums">
                  +{report.cashbackEarned.toLocaleString('ru-RU')} ₽
                </span>
              </div>
            )}

            {report.taxDeductionsEarned > 0 && (
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-600">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  Налоговый вычет 13%
                </span>
                <span className="font-semibold text-emerald-600 tabular-nums">
                  +{report.taxDeductionsEarned.toLocaleString('ru-RU')} ₽
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Expenses & Deductions Breakdown */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Расходы и обязательства
          </h3>
          <div className="bg-slate-50/80 rounded-2xl p-4 border border-slate-100 space-y-2.5 text-xs sm:text-sm">
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Обязательные расходы (жизнь, аренда, еда)</span>
              <span className="font-medium text-slate-900 tabular-nums">
                -{report.mandatoryExpensesPaid.toLocaleString('ru-RU')} ₽
              </span>
            </div>

            {report.optionalExpensesPaid > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Необязательные радости (отпуск, покупки)</span>
                <span className="font-medium text-slate-700 tabular-nums">
                  -{report.optionalExpensesPaid.toLocaleString('ru-RU')} ₽
                </span>
              </div>
            )}

            {report.insurancePaid > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Полисы страхования (ДМС, имущество)</span>
                <span className="font-medium text-slate-700 tabular-nums">
                  -{report.insurancePaid.toLocaleString('ru-RU')} ₽
                </span>
              </div>
            )}

            {report.loanPaymentsPaid > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Платежи по кредитам в банке</span>
                <span className="font-medium text-rose-600 tabular-nums">
                  -{report.loanPaymentsPaid.toLocaleString('ru-RU')} ₽
                </span>
              </div>
            )}

            {report.creditCardInterestPaid > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Проценты и штрафы по кредитной карте</span>
                <span className="font-semibold text-rose-600 tabular-nums">
                  -{report.creditCardInterestPaid.toLocaleString('ru-RU')} ₽
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Current Macro News of the Year from AI */}
        {currentNews && (
          <div
            className={`p-4 rounded-2xl border text-xs sm:text-sm space-y-2.5 ${
              currentNews.cycleType === 'CRISIS' || currentNews.cycleType === 'STAGFLATION'
                ? 'bg-rose-50/80 border-rose-200 text-rose-950'
                : currentNews.cycleType === 'BOOM' || currentNews.cycleType === 'TECH_RALLY'
                ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                : 'bg-purple-50/80 border-purple-200 text-purple-950'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5 opacity-85">
                {currentNews.cycleType === 'CRISIS' || currentNews.cycleType === 'STAGFLATION' ? (
                  <Flame className="w-4 h-4 text-rose-600 animate-pulse" />
                ) : currentNews.cycleType === 'BOOM' || currentNews.cycleType === 'TECH_RALLY' ? (
                  <Rocket className="w-4 h-4 text-emerald-600" />
                ) : (
                  <Sparkles className="w-4 h-4 text-purple-600" />
                )}
                <span>
                  {currentNews.cycleType === 'CRISIS'
                    ? `⚠️ ИИ объявил экономический кризис (${currentNews.durationYears} ${
                        currentNews.durationYears === 1 ? 'год' : 'года'
                      })`
                    : currentNews.cycleType === 'BOOM'
                    ? `🚀 ИИ объявил экономический бум (${currentNews.durationYears} ${
                        currentNews.durationYears === 1 ? 'год' : 'года'
                      })`
                    : '📰 Повестка года от ИИ'}
                </span>
              </span>
              {currentNews.durationYears && currentNews.durationYears > 1 && (
                <span className="px-2 py-0.5 rounded-md bg-white text-[11px] font-bold border shadow-2xs">
                  Срок: {currentNews.durationYears} года
                </span>
              )}
            </div>

            <div>
              <h4 className="font-bold text-sm sm:text-base text-slate-900 font-heading">
                {currentNews.headline}
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed mt-1">
                {currentNews.summary}
              </p>
            </div>

            <div className="flex flex-wrap gap-2 pt-1 font-semibold text-xs">
              <span
                className={`px-2 py-0.5 rounded-md bg-white border ${
                  currentNews.marketImpact.stockMarketMultiplier >= 1
                    ? 'text-emerald-700 border-emerald-200'
                    : 'text-rose-700 border-rose-200'
                }`}
              >
                Рынок акций: {currentNews.marketImpact.stockMarketMultiplier >= 1 ? '+' : ''}
                {((currentNews.marketImpact.stockMarketMultiplier - 1) * 100).toFixed(0)}%
              </span>
              {currentNews.marketImpact.hitSector && (
                <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-900 border border-rose-200">
                  Удар по: <strong>{currentNews.marketImpact.hitSector}</strong>
                </span>
              )}
              {currentNews.marketImpact.favoredSector && (
                <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900 border border-emerald-200">
                  В плюсе: <strong>{currentNews.marketImpact.favoredSector}</strong>
                </span>
              )}
            </div>
          </div>
        )}

        {/* Events that took place */}
        {report.eventsSummary && report.eventsSummary.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              События и инциденты года
            </h3>
            <div className="space-y-1.5">
              {report.eventsSummary.map((eventText, i) => (
                <div
                  key={i}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs sm:text-sm text-slate-700 flex items-center gap-2"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 shrink-0" />
                  <span>{eventText}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Net Joy Change */}
        <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-100 flex items-center justify-between text-xs sm:text-sm">
          <span className="text-amber-900 font-medium">Изменение уровня радости за год:</span>
          <span
            className={`font-bold tabular-nums ${
              report.joyDelta >= 0 ? 'text-emerald-700' : 'text-rose-700'
            }`}
          >
            {report.joyDelta >= 0 ? `+${report.joyDelta}` : report.joyDelta} пунктов
          </span>
        </div>

        {/* Action button */}
        <div className="pt-2">
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-full py-3.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm rounded-2xl shadow-sm transition-colors flex items-center justify-center gap-2"
          >
            <span>Продолжить игру (Год {report.year + 1})</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
