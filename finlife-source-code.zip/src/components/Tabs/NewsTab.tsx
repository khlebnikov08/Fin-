import React, { useState } from 'react';
import { MacroNews } from '../../types/game';
import {
  TrendingUp,
  Newspaper,
  Landmark,
  AlertCircle,
  Sparkles,
  Flame,
  Rocket,
  RefreshCw,
  Clock,
  ShieldAlert,
  ArrowUpRight,
  ArrowDownRight,
  Lightbulb,
} from 'lucide-react';
import { sound } from '../../utils/audio';

interface NewsTabProps {
  currentNews: MacroNews;
  inflationRate: number;
  keyRate: number;
  newsHistory: { year: number; news: MacroNews; inflation: number; keyRate: number }[];
  year: number;
  activeCrisis: MacroNews | null;
  onTriggerAiNews?: (type: 'RANDOM' | 'CRISIS' | 'BOOM' | 'STAGFLATION' | 'TECH', duration?: 1 | 2 | 3) => Promise<void>;
  onTriggerAiGameplayEvent?: () => Promise<void>;
  isGeneratingAi?: boolean;
  autoAiEnabled?: boolean;
  onToggleAutoAi?: () => void;
}

export const NewsTab: React.FC<NewsTabProps> = ({
  currentNews,
  inflationRate,
  keyRate,
  newsHistory,
  year,
  activeCrisis,
  onTriggerAiNews,
  onTriggerAiGameplayEvent,
  isGeneratingAi = false,
  autoAiEnabled = true,
  onToggleAutoAi,
}) => {
  const handleGenerate = async (type: 'RANDOM' | 'CRISIS' | 'BOOM' | 'STAGFLATION' | 'TECH' = 'RANDOM') => {
    if (!onTriggerAiNews || isGeneratingAi) return;
    sound.playClick();
    await onTriggerAiNews(type);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Overview Heading */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h3 className="text-base font-bold text-slate-900 font-heading flex items-center gap-2">
            <span>Макроэкономика и События</span>
            {currentNews.isAiGenerated && (
              <span className="text-[11px] font-bold text-purple-700 bg-purple-50 border border-purple-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                Сгенерировано ИИ (Gemini)
              </span>
            )}
          </h3>
          <p className="text-xs text-slate-500">
            Следите за ставками ЦБ, макроэкономическими шоками и многолетними кризисами
          </p>
        </div>
        <div className="text-xs text-slate-500 font-mono">
          Экономический отчет: Год {year}
        </div>
      </div>

      {/* Active Crisis Banner if running */}
      {activeCrisis && activeCrisis.yearsRemaining && activeCrisis.yearsRemaining > 0 && (
        <div className={`p-4 sm:p-5 rounded-2xl border shadow-xs space-y-3 ${
          activeCrisis.cycleType === 'CRISIS' || activeCrisis.cycleType === 'STAGFLATION'
            ? 'bg-rose-50/70 border-rose-200 text-rose-950'
            : 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
        }`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-rose-200/60">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-white shadow-2xs">
                {activeCrisis.cycleType === 'CRISIS' || activeCrisis.cycleType === 'STAGFLATION' ? (
                  <Flame className="w-5 h-5 text-rose-600 animate-pulse" />
                ) : (
                  <Rocket className="w-5 h-5 text-emerald-600 animate-bounce" />
                )}
              </span>
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider opacity-75">
                  {activeCrisis.cycleType === 'CRISIS' || activeCrisis.cycleType === 'STAGFLATION'
                    ? 'Активен многолетний кризис'
                    : 'Активен многолетний экономический бум'}
                </span>
                <h4 className="font-bold text-sm sm:text-base font-heading">
                  {activeCrisis.headline}
                </h4>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <div className="px-3 py-1 bg-white rounded-xl font-bold text-xs shadow-2xs border border-rose-200/50 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-rose-600" />
                <span>Осталось лет: {activeCrisis.yearsRemaining} из {activeCrisis.durationYears || 3}</span>
              </div>
            </div>
          </div>

          <p className="text-xs leading-relaxed opacity-90">
            {activeCrisis.summary}
          </p>

          {activeCrisis.gameplayAdvice && (
            <div className="p-3 bg-white/80 rounded-xl text-xs flex items-start gap-2 border border-rose-200/50">
              <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block">Совет инвестору:</span>
                <span className="opacity-90">{activeCrisis.gameplayAdvice}</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Autonomous AI Economy Engine Banner & Status */}
      <div className="bg-gradient-to-r from-purple-50/80 via-indigo-50/60 to-blue-50/80 rounded-2xl border border-purple-200/90 p-5 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-600 text-white shadow-xs shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-slate-900 text-sm sm:text-base font-heading">
                  Автономный ИИ-Режиссер экономики (Gemini)
                </h4>
                <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded-md bg-purple-100 text-purple-700 tracking-wider">
                  Нейросеть
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                ИИ самостоятельно оценивает рынки и неожиданно объявляет кризисы на 1-3 года, бумы и отраслевые шоки
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 self-start md:self-auto shrink-0">
            {onToggleAutoAi && (
              <button
                onClick={() => {
                  sound.playClick();
                  onToggleAutoAi();
                }}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-2 ${
                  autoAiEnabled
                    ? 'bg-purple-600 border-purple-600 text-white shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
                title="Автоматическая генерация уникальных новостей и событий каждый ход через нейросеть"
              >
                <span className={`w-2 h-2 rounded-full ${autoAiEnabled ? 'bg-emerald-300 animate-ping' : 'bg-slate-300'}`} />
                <span>ИИ каждый ход: {autoAiEnabled ? 'ВКЛЮЧЕН' : 'ВЫКЛ'}</span>
              </button>
            )}

            {onTriggerAiNews && (
              <button
                onClick={() => handleGenerate('RANDOM')}
                disabled={isGeneratingAi}
                className="py-1.5 px-3 rounded-xl text-xs font-bold bg-white hover:bg-purple-50 border border-purple-200 text-purple-900 shadow-2xs hover:shadow-xs transition-all flex items-center gap-1.5 disabled:opacity-50"
                title="Нейросеть самостоятельно примет решение и сформирует новость года"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-purple-600 ${isGeneratingAi ? 'animate-spin' : ''}`} />
                <span>{isGeneratingAi ? 'ИИ думает...' : 'Запросить решение ИИ'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Explain how AI news directly impact the market */}
        <div className="p-3 bg-white/80 rounded-xl border border-purple-100 text-xs text-slate-700 space-y-1 leading-relaxed">
          <div className="font-semibold text-slate-900 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-600" />
            <span>Как новости ИИ влияют на игровой процесс:</span>
          </div>
          <p className="text-[11px] text-slate-600 pl-3">
            Вам не нужно выбирать наступление кризиса вручную — в любой год нейросеть может объявить кризис (на 1, 2 или 3 года) или бум. Новости автоматически двигают котировки акций по секторам, ключевую ставку ЦБ (доходность вкладов и кредиты), инфляцию (обязательные расходы) и доходность бизнеса.
          </p>
        </div>
      </div>

      {/* 2 Key Macro Indicators (Inflation & Key Rate) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Inflation Card (IMG_9095) */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm sm:text-base">
                  Текущая инфляция в стране
                </h4>
                <span className="text-[11px] text-slate-500">
                  Рост цен на потребительскую корзину
                </span>
              </div>
            </div>
            <span className="text-2xl font-black text-amber-600 tabular-nums">
              +{(inflationRate * 100).toFixed(1)}%
            </span>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed mb-3">
            Инфляция увеличивает сумму обязательных расходов на жизнь.
          </p>

          <div className="p-3 bg-amber-50/50 rounded-xl text-xs text-amber-900 border border-amber-100 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              Рекомендация: дивидендные акции и недвижимость исторически обгоняют инфляцию.
            </span>
          </div>
        </div>

        {/* Central Bank Key Rate */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
                <Landmark className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm sm:text-base">
                  Ключевая ставка Центробанка
                </h4>
                <span className="text-[11px] text-slate-500">
                  Стоимость денег в экономике
                </span>
              </div>
            </div>
            <span className="text-2xl font-black text-blue-600 tabular-nums">
              {(keyRate * 100).toFixed(1)}%
            </span>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed mb-3">
            Высокая ставка дает рекордную доходность по депозитам (до {((keyRate - 0.02) * 100).toFixed(1)}%) и купонам ОФЗ.
          </p>

          <div className="p-3 bg-blue-50/50 rounded-xl text-xs text-blue-900 border border-blue-100 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
            <span>
              Текущие ставки по надежным вкладам: ~{((keyRate - 0.02) * 100).toFixed(1)}% · ОФЗ: ~{((keyRate - 0.01) * 100).toFixed(1)}%.
            </span>
          </div>
        </div>
      </div>

      {/* Main Headline of Current Year */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-700">
            <Newspaper className="w-4 h-4" />
            <span>Текущая повестка (Год {year})</span>
          </div>

          {currentNews.durationYears && currentNews.durationYears > 1 && (
            <span className="text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-0.5 rounded-lg flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              Срок цикла: {currentNews.durationYears} года
            </span>
          )}
        </div>

        <div>
          <h4 className="text-lg sm:text-xl font-bold text-slate-900 font-heading">
            {currentNews.headline}
          </h4>
          <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
            {currentNews.summary}
          </p>
        </div>

        {/* Gameplay Advice */}
        {currentNews.gameplayAdvice && (
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs flex items-start gap-2.5 text-slate-700">
            <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-slate-900 block mb-0.5">Совет игроку:</span>
              <span>{currentNews.gameplayAdvice}</span>
            </div>
          </div>
        )}

        {/* Market Impact Breakdown */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-3 border-t border-slate-100 text-xs">
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-slate-400 block text-[10px]">Влияние на акции</span>
            <span
              className={`font-bold tabular-nums ${
                currentNews.marketImpact.stockMarketMultiplier >= 1
                  ? 'text-emerald-600'
                  : 'text-rose-600'
              }`}
            >
              {currentNews.marketImpact.stockMarketMultiplier >= 1 ? '+' : ''}
              {((currentNews.marketImpact.stockMarketMultiplier - 1) * 100).toFixed(0)}%
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-slate-400 block text-[10px]">Криптовалюта</span>
            <span
              className={`font-bold tabular-nums ${
                currentNews.marketImpact.cryptoMultiplier >= 1
                  ? 'text-purple-600'
                  : 'text-rose-600'
              }`}
            >
              {currentNews.marketImpact.cryptoMultiplier >= 1 ? '+' : ''}
              {((currentNews.marketImpact.cryptoMultiplier - 1) * 100).toFixed(0)}%
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-slate-400 block text-[10px]">Сектор в плюсе</span>
            <span className="font-bold text-emerald-700 truncate block">
              {currentNews.marketImpact.favoredSector || 'Широкий рынок'}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-slate-400 block text-[10px]">Сектор под ударом</span>
            <span className="font-bold text-rose-700 truncate block">
              {currentNews.marketImpact.hitSector || 'Без прямых потерь'}
            </span>
          </div>
        </div>
      </div>

      {/* Archive of Past News */}
      {newsHistory.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs space-y-3">
          <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Хроника прошлых лет
          </h5>

          <div className="space-y-2">
            {newsHistory.map((item, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
              >
                <div>
                  <span className="font-semibold text-slate-900">Год {item.year}: {item.news.headline}</span>
                  <p className="text-slate-500 mt-0.5 line-clamp-1">{item.news.summary}</p>
                </div>
                <div className="flex items-center gap-3 shrink-0 text-slate-600 font-mono">
                  <span>Инфляция: {(item.inflation * 100).toFixed(1)}%</span>
                  <span>Ставка: {(item.keyRate * 100).toFixed(1)}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
