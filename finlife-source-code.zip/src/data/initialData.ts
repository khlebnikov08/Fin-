import {
  CharacterPreset,
  LifeGoal,
  StockAsset,
  BondAsset,
  CryptoAsset,
  BusinessOrRealEstate,
  InsurancePolicy,
  EducationTier,
  OptionalExpense,
  GameRandomEvent,
  MacroNews,
} from '../types/game';

export const INITIAL_CHARACTERS: CharacterPreset[] = [
  {
    id: 'it_specialist',
    name: 'Алексей (IT-разработчик)',
    role: 'Специалист в технологиях',
    description: 'Хороший стартовый оклад, интерес к инвестициям и технологиям. Уверенный старт с комфортным бюджетом.',
    initialSalary: 1200000, // 100 000 ₽ / мес
    initialCash: 1600000,   // 400 000 ₽ накопления + 1 200 000 ₽ бюджет года
    initialJoy: 75,
    avatarIcon: 'Laptop',
  },
  {
    id: 'entrepreneur',
    name: 'Елена (Предприниматель)',
    role: 'Энергичный стартапер',
    description: 'Высокая стартовая мотивация, готовность рисковать в бизнесе и крипте, переменчивый доход.',
    initialSalary: 840000, // 70 000 ₽ / мес
    initialCash: 1440000,  // 600 000 ₽ капитал + 840 000 ₽ бюджет года
    initialJoy: 82,
    avatarIcon: 'Rocket',
  },
  {
    id: 'corporate_analyst',
    name: 'Дмитрий (Финансовый аналитик)',
    role: 'Осторожный стратег',
    description: 'Глубокое понимание облигаций и акций, стабильная карьера, дисциплинированный бюджет.',
    initialSalary: 1080000, // 90 000 ₽ / мес
    initialCash: 1580000,   // 500 000 ₽ капитал + 1 080 000 ₽ бюджет года
    initialJoy: 70,
    avatarIcon: 'Briefcase',
  },
  {
    id: 'young_graduate',
    name: 'София (Молодой специалист)',
    role: 'Амбициозный выпускник',
    description: 'Небольшой стартовый капитал, но колоссальный простор для роста через образование.',
    initialSalary: 600000, // 50 000 ₽ / мес
    initialCash: 800000,   // 200 000 ₽ капитал + 600 000 ₽ бюджет года
    initialJoy: 88,
    avatarIcon: 'GraduationCap',
  },
];

export const INITIAL_LIFE_GOALS: LifeGoal[] = [
  {
    id: 'mode_10_years',
    title: 'Классика: 10 Игровых Лет',
    description: 'Максимально приумножьте капитал ровно за 10 лет, сохранив уровень радости не менее 80 пунктов.',
    targetCapital: 10000000,
    minJoy: 80,
  },
  {
    id: 'goal_apartment',
    title: 'Мечта: Своё жильё без ипотеки',
    description: 'Купить комфортную квартиру за 7 000 000 ₽, накопить подушку от 3 000 000 ₽ и сохранить радость 80+.',
    targetCapital: 10000000,
    minJoy: 80,
    requiredAssets: { hasApartment: true },
  },
  {
    id: 'goal_fire',
    title: 'Финансовая Свобода (FIRE)',
    description: 'Сформировать пассивный доход (дивиденды, купоны, аренда) не менее 1 200 000 ₽ в год при радости 80+.',
    targetCapital: 12000000,
    minJoy: 80,
    requiredAssets: { passiveIncomeTarget: 1200000 },
  },
  {
    id: 'goal_business_empire',
    title: 'Бизнес-Империя',
    description: 'Создать прибыльный бизнес и накопить капитал свыше 25 000 000 ₽ при уровне радости 85+.',
    targetCapital: 25000000,
    minJoy: 85,
    requiredAssets: { hasBusiness: true },
  },
  {
    id: 'goal_multimillionaire',
    title: 'Капитал 50 000 000 ₽',
    description: 'Амбициозная цель: достичь чистого капитала в 50 млн рублей. Играйте столько лет, сколько потребуется!',
    targetCapital: 50000000,
    minJoy: 75,
  },
  {
    id: 'goal_sandbox',
    title: 'Бесконечная Песочница',
    description: 'Играйте без жестких ограничений и дедлайнов. Живите полной жизнью и фиксируйте рекорды когда захотите.',
    targetCapital: 0,
    minJoy: 60,
  },
];

export const INITIAL_STOCKS: StockAsset[] = [
  {
    id: 'stock_tech',
    name: 'ЯндексТех (YNDX)',
    ticker: 'YNDX',
    sector: 'IT & ИИ',
    description: 'Ведущий российский технологический холдинг: поиск, такси, облачные сервисы и разработка ИИ.',
    price: 3800,
    prevPrice: 3500,
    dividendYield: 0.035, // 3.5%
    risk: 'medium',
    ownedShares: 0,
    history: [3200, 3500, 3800],
  },
  {
    id: 'stock_bank',
    name: 'СберБанк (SBER)',
    ticker: 'SBER',
    sector: 'Финансы & Финтех',
    description: 'Крупнейший банк страны с передовой экосистемой сервисов и высокими рекордными дивидендами.',
    price: 290,
    prevPrice: 265,
    dividendYield: 0.125, // 12.5%
    risk: 'low',
    ownedShares: 0,
    history: [240, 265, 290],
  },
  {
    id: 'stock_oil',
    name: 'ЛукНефть (LKOH)',
    ticker: 'LKOH',
    sector: 'Нефть & Газ',
    description: 'Крупный сырьевой гигант. Стабильный бизнес с традиционно щедрыми дивидендами дважды в год.',
    price: 6400,
    prevPrice: 6100,
    dividendYield: 0.11, // 11%
    risk: 'low',
    ownedShares: 0,
    history: [5800, 6100, 6400],
  },
  {
    id: 'stock_retail',
    name: 'МагнитТорг (MGNT)',
    ticker: 'MGNT',
    sector: 'Потребительский',
    description: 'Федеральная сеть супермаркетов и маркетплейсов. Устойчивый защитный бизнес при любой инфляции.',
    price: 5100,
    prevPrice: 4900,
    dividendYield: 0.08, // 8.0%
    risk: 'low',
    ownedShares: 0,
    history: [4700, 4900, 5100],
  },
  {
    id: 'stock_metal',
    name: 'НорНикель (GMKN)',
    ticker: 'GMKN',
    sector: 'Металлургия',
    description: 'Мировой лидер по добыче палладия и высокосортного никеля. Экспортная выручка и валютный хедж.',
    price: 15400,
    prevPrice: 14800,
    dividendYield: 0.095, // 9.5%
    risk: 'medium',
    ownedShares: 0,
    history: [14200, 14800, 15400],
  },
  {
    id: 'stock_ecom',
    name: 'ОзонМаркет (OZON)',
    ticker: 'OZON',
    sector: 'Электронная коммерция',
    description: 'Быстрорастущий маркетплейс и финтех. Высокие темпы роста оборота и расширение логистики.',
    price: 3200,
    prevPrice: 2800,
    dividendYield: 0.0,
    risk: 'medium',
    ownedShares: 0,
    history: [2400, 2800, 3200],
  },
  {
    id: 'stock_dev',
    name: 'СамолетДевелоп (SMLT)',
    ticker: 'SMLT',
    sector: 'Девелопмент',
    description: 'Один из крупнейших застройщиков жилья. Высокая чувствительность к ипотечным ставкам ЦБ.',
    price: 2700,
    prevPrice: 2900,
    dividendYield: 0.07, // 7%
    risk: 'medium',
    ownedShares: 0,
    history: [3100, 2900, 2700],
  },
  {
    id: 'stock_biotech',
    name: 'БиоГенетика (BGEN)',
    ticker: 'BGEN',
    sector: 'Биотехнологии',
    description: 'Инновационная лаборатория генной терапии. Огромный потенциал взрывного роста при высоком риске.',
    price: 1200,
    prevPrice: 1000,
    dividendYield: 0.0,
    risk: 'high',
    ownedShares: 0,
    history: [800, 1000, 1200],
  },
];

export const INITIAL_BONDS: BondAsset[] = [
  {
    id: 'bond_ofz',
    name: 'ОФЗ 26238 (Гособлигации РФ)',
    type: 'OFZ',
    couponRate: 0.115, // 11.5%
    faceValue: 1000,
    riskText: 'Высшая надежность. Гарантировано Минфином РФ.',
    defaultChance: 0.0,
    ownedCount: 0,
  },
  {
    id: 'bond_corp',
    name: 'СберЛизинг Бонус-01',
    type: 'CORP',
    couponRate: 0.145, // 14.5%
    faceValue: 1000,
    riskText: 'Надежные корпоративные облигации системообразующего эмитента.',
    defaultChance: 0.005,
    ownedCount: 0,
  },
  {
    id: 'bond_high_yield',
    name: 'ВДО «ТехноРитейл Групп»',
    type: 'HIGH_YIELD',
    couponRate: 0.21, // 21%
    faceValue: 1000,
    riskText: 'Высокодоходные облигации (ВДО). Высокий купон, риск дефолта 5% в год.',
    defaultChance: 0.05,
    ownedCount: 0,
  },
];

export const INITIAL_CRYPTO: CryptoAsset[] = [
  {
    id: 'btc',
    name: 'Bitcoin',
    symbol: 'BTC',
    price: 5800000, // in rubles
    prevPrice: 5800000,
    volatility: 0.45,
    ownedAmount: 0,
    history: [4200000, 5100000, 5800000],
  },
  {
    id: 'memecoin',
    name: 'DogeShiba Rocket',
    symbol: 'DSR',
    price: 15,
    prevPrice: 15,
    volatility: 0.95,
    ownedAmount: 0,
    history: [5, 25, 15],
  },
];

export const INITIAL_BUSINESS_AND_REAL_ESTATE: BusinessOrRealEstate[] = [
  {
    id: 'asset_studio',
    title: 'Инвестиционная студия под аренду',
    type: 'REAL_ESTATE',
    cost: 4500000,
    annualIncomeRate: 0.08, // 8% net annual rent
    owned: false,
    description: 'Уютная квартира-студия у метро. Приносит 360 000 ₽ арендного дохода в год и дорожает с инфляцией.',
    maintenanceCost: 35000,
  },
  {
    id: 'asset_cafe',
    title: 'Специалити-кофейня «Зерно & Смысл»',
    type: 'BUSINESS',
    cost: 1200000,
    annualIncomeRate: 0.28, // 28% annual profit
    owned: false,
    description: 'Популярная кофейня в центре города. Высокая окупаемость, требует внимания и маркетинга.',
    maintenanceCost: 80000,
  },
  {
    id: 'asset_it_agency',
    title: 'IT-агентство цифровых продуктов',
    type: 'BUSINESS',
    cost: 2800000,
    annualIncomeRate: 0.35, // 35% annual profit
    owned: false,
    description: 'Команда сильных специалистов по заказной разработке и внедрению ИИ решений.',
    maintenanceCost: 150000,
  },
  {
    id: 'asset_gold',
    title: 'Инвестиционные золотые слитки (ОМС)',
    type: 'GOLD',
    cost: 500000,
    annualIncomeRate: 0.05, // capital preservation + inflation
    owned: false,
    description: 'Золотой резерв высшей пробы. Идеальный инструмент защиты от валютных кризисов и инфляции.',
    maintenanceCost: 0,
  },
];

export const INITIAL_INSURANCES: InsurancePolicy[] = [
  {
    type: 'HEALTH_DMS',
    name: 'Полис ДМС (Здоровье)',
    annualCost: 45000,
    active: false,
    description: 'Полное покрытие медицинских расходов при травмах, операциях и тяжелых заболеваниях.',
  },
  {
    type: 'HOME',
    name: 'Страхование квартиры и имущества',
    annualCost: 24000,
    active: false,
    description: 'Защита от пожара, затопления соседей и кражи. Покрывает ущерб до 2 000 000 ₽.',
  },
  {
    type: 'CAR_CASCO',
    name: 'КАСКО (Автомобиль)',
    annualCost: 65000,
    active: false,
    description: 'Полная защита вашего автомобиля от ДТП, града, падения веток и угона.',
  },
];

export const INITIAL_EDUCATION_TIERS: EducationTier[] = [
  {
    id: 'courses_pro',
    name: 'Профессиональные курсы повышения квалификации',
    cost: 120000,
    salaryBonusMultiplier: 0.18,
    joyBonus: 6,
    description: 'Интенсивные курсы по актуальным технологиям, менеджменту и продуктивности. +18% к зарплате.',
    completed: false,
  },
  {
    id: 'second_degree',
    name: 'Второе высшее образование',
    cost: 380000,
    salaryBonusMultiplier: 0.32,
    joyBonus: 10,
    description: 'Фундаментальная подготовка по смежной специальности (Финансы, Управление). +32% к зарплате.',
    completed: false,
  },
  {
    id: 'mba_program',
    name: 'Бизнес-школа: Программа Executive MBA',
    cost: 950000,
    salaryBonusMultiplier: 0.55,
    joyBonus: 14,
    description: 'Стратегический менеджмент, международный нетворкинг и топ-руководство. +55% к зарплате.',
    completed: false,
  },
  {
    id: 'abroad_study',
    name: 'Магистратура за рубежом / Стажировка',
    cost: 1800000,
    salaryBonusMultiplier: 0.85,
    joyBonus: 22,
    description: 'Престижный диплом ведущего мирового университета и свободный иностранный язык. +85% к зарплате.',
    completed: false,
  },
];

export const OPTIONAL_EXPENSES_POOL: OptionalExpense[] = [
  {
    id: 'opt_vacation_bali',
    title: 'Отпуск мечты на океане',
    cost: 220000,
    joyDeltaIfAccepted: 16,
    joyDeltaIfDeclined: -4,
    category: 'LEISURE',
    description: 'Две недели серфинга, солнца, тропических закатов и полной перезагрузки нервной системы.',
  },
  {
    id: 'opt_flagship_phone',
    title: 'Новый флагманский смартфон',
    cost: 110000,
    joyDeltaIfAccepted: 8,
    joyDeltaIfDeclined: -2,
    category: 'PURCHASE',
    description: 'Ультрасовременная камера, премиальный титановый корпус и мгновенная скорость работы.',
  },
  {
    id: 'opt_fitness_membership',
    title: 'Премиальный фитнес-клуб со SPA и бассейном',
    cost: 75000,
    joyDeltaIfAccepted: 9,
    joyDeltaIfDeclined: 0,
    category: 'LEISURE',
    description: 'Годовой безлимитный абонемент, персональные тренировки и забота о долголетии.',
  },
  {
    id: 'opt_car_purchase',
    title: 'Покупка надежного автомобиля',
    cost: 1900000,
    joyDeltaIfAccepted: 24,
    joyDeltaIfDeclined: 0,
    permanentAnnualCostDelta: 130000, // maintenance, fuel, tax
    category: 'PURCHASE',
    isOneTimeAssetPurchase: 'CAR',
    description: 'Комфортный седан. Дарит независимость и радость поездок, но добавляет расходы на бензин и ТО (+130 000 ₽/год).',
  },
  {
    id: 'opt_own_apartment',
    title: 'Покупка собственной квартиры',
    cost: 7200000,
    joyDeltaIfAccepted: 35,
    joyDeltaIfDeclined: 0,
    permanentAnnualCostDelta: -280000, // saves rent!
    category: 'PURCHASE',
    isOneTimeAssetPurchase: 'APARTMENT',
    description: 'Просторная светлая квартира в хорошем районе. Освобождает от трат на аренду (-280 000 ₽/год)!',
  },
  {
    id: 'opt_fine_dining',
    title: 'Гастрономический уикенд и рестораны',
    cost: 45000,
    joyDeltaIfAccepted: 6,
    joyDeltaIfDeclined: -1,
    category: 'LEISURE',
    description: 'Ужины в авторских ресторанах с друзьями, дегустации и яркие впечатления.',
  },
  {
    id: 'opt_charity',
    title: 'Благотворительный взнос в фонд помощи',
    cost: 50000,
    joyDeltaIfAccepted: 12,
    joyDeltaIfDeclined: 0,
    category: 'FAMILY',
    description: 'Помощь детским больницам и приютам животных. Наполняет жизнь глубоким смыслом.',
  },
];

export const RANDOM_EVENTS_POOL: GameRandomEvent[] = [
  {
    id: 'ev_lottery',
    title: 'Удача в лотерее!',
    description: 'Купленный ради забавы праздничный билет принес солидный денежный выигрыш!',
    cashDelta: 120000,
    joyDelta: 10,
    iconType: 'good',
  },
  {
    id: 'ev_bonus',
    title: 'Годовая премия за перевыполнение KPI',
    description: 'Руководство высоко оценило ваш вклад в ключевой проект года и выплатило щедрый бонус.',
    cashDelta: 240000,
    joyDelta: 12,
    iconType: 'good',
  },
  {
    id: 'ev_lost_phone',
    title: 'Утерян дорогой телефон',
    description: 'Смартфон выпал в такси или кафе, вернуть не удалось. Пришлось срочно купить новый.',
    cashDelta: -65000,
    joyDelta: -6,
    iconType: 'bad',
  },
  {
    id: 'ev_medical_operation',
    title: 'Внезапная операция и лечение',
    description: 'Острое воспаление потребовало срочной медицинской помощи и курса реабилитации.',
    cashDelta: -190000,
    joyDelta: -14,
    coveredByInsurance: 'HEALTH_DMS',
    insuranceAvoidedLoss: 190000,
    iconType: 'bad',
  },
  {
    id: 'ev_car_accident',
    title: 'ДТП на скользкой дороге',
    description: 'Небольшая авария на перекрестке повредила бампер, фары и крыло автомобиля.',
    cashDelta: -140000,
    joyDelta: -10,
    requiresCar: true,
    coveredByInsurance: 'CAR_CASCO',
    insuranceAvoidedLoss: 140000,
    iconType: 'bad',
  },
  {
    id: 'ev_home_flood',
    title: 'Прорыв трубы у соседей сверху',
    description: 'Затопило потолок и стены в спальне, паркет вздулся. Необходим ремонт.',
    cashDelta: -220000,
    joyDelta: -12,
    requiresApartment: true,
    coveredByInsurance: 'HOME',
    insuranceAvoidedLoss: 220000,
    iconType: 'bad',
  },
  {
    id: 'ev_debt_returned',
    title: 'Возврат старого забытого долга',
    description: 'Школьный друг внезапно вышел на связь и полностью вернул долг с процентами за давность.',
    cashDelta: 50000,
    joyDelta: 6,
    iconType: 'good',
  },
  {
    id: 'ev_conference_speaker',
    title: 'Гонорар за выступление на форуме',
    description: 'Вас пригласили экспертом на экономический форум. Выступление прошло с фурором!',
    cashDelta: 95000,
    joyDelta: 11,
    iconType: 'good',
  },
  {
    id: 'ev_laptop_broken',
    title: 'Сломался рабочий ноутбук',
    description: 'Материнская плата сгорела от перепада напряжения прямо посреди дедлайна.',
    cashDelta: -85000,
    joyDelta: -5,
    iconType: 'bad',
  },
  {
    id: 'ev_dog_adoption',
    title: 'Взяли щенка из приюта',
    description: 'Расходы на ветеринара, прививки и амуницию, но море искренней радости и тепла в доме!',
    cashDelta: -30000,
    joyDelta: 18,
    iconType: 'good',
  },
  {
    id: 'ev_tax_fine',
    title: 'Перерасчет налогов и пени',
    description: 'Налоговая инспекция прислала уведомление о доплате налога на имущество за прошлые годы.',
    cashDelta: -35000,
    joyDelta: -4,
    iconType: 'bad',
  },
];

export const MACRO_NEWS_POOL: MacroNews[] = [
  {
    id: 'news_ai_boom',
    headline: 'Технологический бум: прорыв в генеративном ИИ',
    summary: 'Акции технологических компаний взлетели на рекордные уровни на фоне внедрения нейросетей.',
    inflationDelta: 0.01,
    keyRateDelta: 0.0,
    marketImpact: {
      stockMarketMultiplier: 1.25,
      cryptoMultiplier: 1.4,
      favoredSector: 'IT & ИИ',
    },
  },
  {
    id: 'news_oil_rally',
    headline: 'Мировое ралли цен на энергоносители',
    summary: 'Решения экспортеров нефти привели к скачку цен на черное золото. Нефтяники платят супердивиденды.',
    inflationDelta: 0.02,
    keyRateDelta: 0.01,
    marketImpact: {
      stockMarketMultiplier: 1.15,
      cryptoMultiplier: 1.05,
      favoredSector: 'Нефть & Газ',
    },
  },
  {
    id: 'news_central_bank_hike',
    headline: 'Центробанк повысил ключевую ставку для борьбы с инфляцией',
    summary: 'Доходности банковских вкладов и облигаций выросли, а кредиты стали дороже.',
    inflationDelta: -0.015,
    keyRateDelta: 0.03,
    marketImpact: {
      stockMarketMultiplier: 0.92,
      cryptoMultiplier: 0.85,
    },
  },
  {
    id: 'news_consumer_growth',
    headline: 'Рост потребительской активности и розничных продаж',
    summary: 'Супермаркеты и торговые сети показывают сильную отчетность, дивиденды растут.',
    inflationDelta: 0.005,
    keyRateDelta: 0.0,
    marketImpact: {
      stockMarketMultiplier: 1.1,
      cryptoMultiplier: 1.0,
      favoredSector: 'Потребительский',
    },
  },
  {
    id: 'news_crypto_spring',
    headline: 'Крипто-весна: халвинг Биткоина и приток институционалов',
    summary: 'Криптовалютные рынки демонстрируют экспоненциальный взлет, привлекая миллионы трейдеров.',
    inflationDelta: 0.0,
    keyRateDelta: 0.0,
    marketImpact: {
      stockMarketMultiplier: 1.05,
      cryptoMultiplier: 1.75,
    },
  },
  {
    id: 'news_global_uncertainty',
    headline: 'Торговые ограничения и мировая волатильность',
    summary: 'Инвесторы уходят в защитные инструменты: золото, государственные облигации и депозиты.',
    inflationDelta: 0.025,
    keyRateDelta: 0.02,
    marketImpact: {
      stockMarketMultiplier: 0.88,
      cryptoMultiplier: 0.75,
    },
  },
];
