import { MacroNews, GameRandomEvent } from '../types/game';

// Procedural fallback events for offline or static hosting
const PROCEDURAL_MULTI_YEAR_EVENTS: MacroNews[] = [
  {
    id: 'proc_banking_crisis',
    headline: 'Глобальный банковский кризис ликвидности',
    summary: 'Крах нескольких зарубежных банков вызвал панику на развивающихся рынках. ЦБ экстренно ужесточает монетарную политику, банки поднимают ставки по депозитам до пиковых значений.',
    durationYears: 3,
    yearsRemaining: 3,
    cycleType: 'CRISIS',
    inflationDelta: 0.04,
    keyRateDelta: 0.045,
    isAiGenerated: false,
    gameplayAdvice: 'Зафиксируйте рекордные ставки по вкладам на 2–3 года и выкупайте просевшие дивидендные акции на дне.',
    marketImpact: {
      stockMarketMultiplier: 0.72,
      cryptoMultiplier: 0.55,
      favoredSector: 'Потребительский',
      hitSector: 'Финансы & Финтех',
      salaryMultiplier: 0.95,
      businessMultiplier: 0.80,
    },
  },
  {
    id: 'proc_commodities_boom',
    headline: 'Сырьевой суперцикл: рекордный взлет цен на нефть и металлы',
    summary: 'Мировой дефицит сырья разогнал котировки углеводородов и цветных металлов. В страну хлынул поток валютной выручки, бюджет переполнен.',
    durationYears: 2,
    yearsRemaining: 2,
    cycleType: 'BOOM',
    inflationDelta: -0.02,
    keyRateDelta: -0.025,
    isAiGenerated: false,
    gameplayAdvice: 'Сырьевые экспортеры платят сверхдивиденды. Самое время фиксировать прибыль в акциях нефти и металлов.',
    marketImpact: {
      stockMarketMultiplier: 1.35,
      cryptoMultiplier: 1.40,
      favoredSector: 'Нефть & Газ',
      hitSector: 'Девелопмент',
      salaryMultiplier: 1.15,
      businessMultiplier: 1.25,
    },
  },
  {
    id: 'proc_ai_tech_singularity',
    headline: 'Технологическая революция: прорыв в ИИ и квантовых чипах',
    summary: 'Отечественные IT-холдинги представили революционные модели ИИ для автоматизации предприятий. Отрасль IT привлекает колоссальные венчурные инвестиции.',
    durationYears: 2,
    yearsRemaining: 2,
    cycleType: 'TECH_RALLY',
    inflationDelta: -0.01,
    keyRateDelta: -0.015,
    isAiGenerated: false,
    gameplayAdvice: 'Акции IT и e-commerce бьют исторические рекорды. Инвестиции в профессиональное образование окупаются втрое быстрее.',
    marketImpact: {
      stockMarketMultiplier: 1.28,
      cryptoMultiplier: 1.80,
      favoredSector: 'IT & ИИ',
      hitSector: 'Металлургия',
      salaryMultiplier: 1.20,
      businessMultiplier: 1.15,
    },
  },
  {
    id: 'proc_stagflation',
    headline: 'Затяжная стагфляция и разрыв логистических цепочек',
    summary: 'Высокая инфляция совпала со спадом потребительского спроса. Центральный Банк удерживает высокую ставку, кредитование заморожено.',
    durationYears: 3,
    yearsRemaining: 3,
    cycleType: 'STAGFLATION',
    inflationDelta: 0.05,
    keyRateDelta: 0.035,
    isAiGenerated: false,
    gameplayAdvice: 'Откажитесь от новых кредитов. Надежные облигации ОФЗ и вклады с защитой АСВ помогут сберечь капитал.',
    marketImpact: {
      stockMarketMultiplier: 0.78,
      cryptoMultiplier: 0.65,
      favoredSector: 'Потребительский',
      hitSector: 'Девелопмент',
      salaryMultiplier: 0.90,
      businessMultiplier: 0.75,
    },
  },
  {
    id: 'proc_crypto_spring',
    headline: 'Институциональное признание цифровых валют & Крипто-бум',
    summary: 'Крупнейшие мировые фонды включили криптовалюты в золотой стандарт резервов. Котировки цифровых активов демонстрируют взрывной экспоненциальный рост.',
    durationYears: 1,
    yearsRemaining: 1,
    cycleType: 'BOOM',
    inflationDelta: 0.01,
    keyRateDelta: 0.0,
    isAiGenerated: false,
    gameplayAdvice: 'Зафиксируйте часть прибыли в крипте и переложите в реальные активы — недвижимость или бизнес.',
    marketImpact: {
      stockMarketMultiplier: 1.12,
      cryptoMultiplier: 2.25,
      favoredSector: 'Финансы & Финтех',
      hitSector: undefined,
      salaryMultiplier: 1.0,
      businessMultiplier: 1.05,
    },
  },
  {
    id: 'proc_real_estate_stimulus',
    headline: 'Масштабная государственная ипотечная программа & Бум строек',
    summary: 'Государство запустило льготную программу субсидирования жилья под 6%. Спрос на недвижимость бьет рекорды, строительный сектор на подъеме.',
    durationYears: 2,
    yearsRemaining: 2,
    cycleType: 'BOOM',
    inflationDelta: 0.02,
    keyRateDelta: 0.01,
    isAiGenerated: false,
    gameplayAdvice: 'Девелоперы получают рекордную выручку. Покупка собственной квартиры сейчас застрахует от дальнейшего удорожания аренды.',
    marketImpact: {
      stockMarketMultiplier: 1.20,
      cryptoMultiplier: 0.95,
      favoredSector: 'Девелопмент',
      hitSector: 'Нефть & Газ',
      salaryMultiplier: 1.05,
      businessMultiplier: 1.20,
    },
  },
];

export async function requestAiMacroNews(params: {
  year: number;
  inflationRate: number;
  keyRate: number;
  requestedType?: 'RANDOM' | 'CRISIS' | 'BOOM' | 'STAGFLATION' | 'TECH';
  requestedDuration?: 1 | 2 | 3;
}): Promise<MacroNews> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000); // 7 sec timeout

    const response = await fetch('/api/generate-news', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      const data = await response.json();
      if (data && data.headline) {
        return {
          ...data,
          isAiGenerated: true,
        };
      }
    }
  } catch (err) {
    // Expected on static hosting or offline preview: proceed seamlessly to procedural generator
    console.info('Using procedural macro event generator (backend/AI offline):', err);
  }

  // Fallback to rich procedural generator with 1-3 year duration
  const filtered = params.requestedType && params.requestedType !== 'RANDOM'
    ? PROCEDURAL_MULTI_YEAR_EVENTS.filter((e) => e.cycleType === params.requestedType)
    : PROCEDURAL_MULTI_YEAR_EVENTS;

  const pool = filtered.length > 0 ? filtered : PROCEDURAL_MULTI_YEAR_EVENTS;
  const picked = pool[Math.floor(Math.random() * pool.length)];

  const duration = params.requestedDuration || picked.durationYears || (Math.floor(Math.random() * 3) + 1);

  return {
    ...picked,
    id: `macro_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    durationYears: duration,
    yearsRemaining: duration,
    isAiGenerated: false,
  };
}

// Procedural fallback gameplay events
const PROCEDURAL_GAMEPLAY_EVENTS: GameRandomEvent[] = [
  {
    id: 'proc_event_startup',
    title: 'Предложение стать ангельским инвестором',
    description: 'Бывший коллега запустил перспективный финтех-проект и предлагает выкупить долю в компании с солидным дисконтом.',
    cashDelta: -120000,
    joyDelta: 18,
    iconType: 'good',
    isAiGenerated: false,
    choices: [
      {
        id: 'invest',
        label: 'Инвестировать (-120 000 ₽, +18 радости)',
        cashDelta: -120000,
        joyDelta: 18,
        description: 'Вы стали совладельцем стартапа и воодушевлены новыми перспективами!',
      },
      {
        id: 'skip',
        label: 'Отказаться (0 ₽, 0 радости)',
        cashDelta: 0,
        joyDelta: 0,
        description: 'Вы предпочли сохранить ликвидность.',
      },
    ],
  },
  {
    id: 'proc_event_bonus',
    title: 'Рекордная годовая премия за проект',
    description: 'Руководство компании оценило ваш выдающийся вклад в запуск ключевого продукта и начислило солидный бонус.',
    cashDelta: 240000,
    joyDelta: 20,
    iconType: 'good',
    isAiGenerated: false,
  },
  {
    id: 'proc_event_medical',
    title: 'Сложное стоматологическое лечение',
    description: 'Потребовалась срочная установка имплантов и комплексная терапия зубов.',
    cashDelta: -85000,
    joyDelta: -10,
    coveredByInsurance: 'HEALTH_DMS',
    insuranceAvoidedLoss: 85000,
    iconType: 'bad',
    isAiGenerated: false,
  },
  {
    id: 'proc_event_car_accident',
    title: 'Поломка трансмиссии на загородной трассе',
    description: 'Внезапная поломка коробки передач потребовала эвакуатора и капитального ремонта в авторизованном сервисе.',
    cashDelta: -110000,
    joyDelta: -12,
    requiresCar: true,
    coveredByInsurance: 'CAR_CASCO',
    insuranceAvoidedLoss: 110000,
    iconType: 'bad',
    isAiGenerated: false,
  },
  {
    id: 'proc_event_home_leak',
    title: 'Залив соседей сверху & Ремонт',
    description: 'Прорыв трубы в перекрытиях повредил отделку потолка и дизайнерский паркет.',
    cashDelta: -95000,
    joyDelta: -12,
    requiresApartment: true,
    coveredByInsurance: 'HOME',
    insuranceAvoidedLoss: 95000,
    iconType: 'bad',
    isAiGenerated: false,
  },
  {
    id: 'proc_event_course_grant',
    title: 'Государственный грант на повышение квалификации',
    description: 'Вы выиграли стипендию на прохождение элитного executive-курса по стратегическому менеджменту и ИИ.',
    cashDelta: 50000,
    joyDelta: 15,
    iconType: 'good',
    isAiGenerated: false,
  },
];

export async function requestAiGameplayEvent(params: {
  characterName: string;
  role: string;
  year: number;
  cash: number;
  netWorth: number;
  annualSalary: number;
  joy: number;
  hasCar: boolean;
  hasApartment: boolean;
  hasBusiness: boolean;
  activeCrisisTitle?: string;
}): Promise<GameRandomEvent> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000);

    const response = await fetch('/api/generate-gameplay-event', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      const data = await response.json();
      if (data && data.title) {
        return {
          ...data,
          isAiGenerated: true,
        };
      }
    }
  } catch (err) {
    console.info('Using procedural event generator (AI/backend offline):', err);
  }

  // Filter procedural events based on assets
  const eligible = PROCEDURAL_GAMEPLAY_EVENTS.filter((ev) => {
    if (ev.requiresCar && !params.hasCar) return false;
    if (ev.requiresApartment && !params.hasApartment) return false;
    return true;
  });

  const picked = eligible[Math.floor(Math.random() * eligible.length)] || PROCEDURAL_GAMEPLAY_EVENTS[0];
  return {
    ...picked,
    id: `event_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    isAiGenerated: false,
  };
}
