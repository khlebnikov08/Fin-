import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  GameMode,
  LifeGoal,
  CharacterPreset,
  StockAsset,
  BondAsset,
  BankDeposit,
  CryptoAsset,
  BusinessOrRealEstate,
  Loan,
  CreditCard,
  DebitCard,
  InsurancePolicy,
  EducationTier,
  OptionalExpense,
  GameRandomEvent,
  EventChoice,
  MacroNews,
  TurnReport,
  YearHistoryPoint,
  LeaderboardEntry,
} from './types/game';
import {
  INITIAL_CHARACTERS,
  INITIAL_LIFE_GOALS,
  INITIAL_STOCKS,
  INITIAL_BONDS,
  INITIAL_CRYPTO,
  INITIAL_BUSINESS_AND_REAL_ESTATE,
  INITIAL_INSURANCES,
  INITIAL_EDUCATION_TIERS,
  OPTIONAL_EXPENSES_POOL,
  RANDOM_EVENTS_POOL,
  MACRO_NEWS_POOL,
} from './data/initialData';
import { Header, ActiveTab } from './components/Header';
import { StatusBar } from './components/StatusBar';
import { OverviewTab } from './components/Tabs/OverviewTab';
import { InvestmentsTab } from './components/Tabs/InvestmentsTab';
import { BankingTab } from './components/Tabs/BankingTab';
import { CareerTab } from './components/Tabs/CareerTab';
import { NewsTab } from './components/Tabs/NewsTab';
import { AnalyticsTab } from './components/Tabs/AnalyticsTab';
import { TurnSummaryModal } from './components/TurnSummaryModal';
import { EventModal } from './components/Modals/EventModal';
import { RulesGuideModal } from './components/Modals/RulesGuideModal';
import { LeaderboardModal } from './components/Modals/LeaderboardModal';
import { GameOverModal } from './components/Modals/GameOverModal';
import { GameSetupModal } from './components/Modals/GameSetupModal';
import { DownloadModal } from './components/Modals/DownloadModal';
import { OnboardingTourModal } from './components/Modals/OnboardingTourModal';
import { calculateMandatoryExpensesBreakdown } from './utils/expenses';
import { requestAiMacroNews, requestAiGameplayEvent } from './services/aiNewsService';
import { sound } from './utils/audio';

const STORAGE_KEY = 'finlife_save_v1';
const LEADERBOARD_KEY = 'finlife_leaderboard_v1';

export default function App() {
  // Navigation & Modals
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [isRulesOpen, setIsRulesOpen] = useState(false);
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [isDownloadOpen, setIsDownloadOpen] = useState(false);
  const [isSetupOpen, setIsSetupOpen] = useState(false);
  const [isGameOverOpen, setIsGameOverOpen] = useState(false);
  const [isTurnSummaryOpen, setIsTurnSummaryOpen] = useState(false);
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(sound.getMuted());
  const [autoAiEnabled, setAutoAiEnabled] = useState(true);

  // Game Meta
  const [playerName, setPlayerName] = useState('Инвестор');
  const [gameMode, setGameMode] = useState<GameMode>('GOAL');
  const [goal, setGoal] = useState<LifeGoal>(INITIAL_LIFE_GOALS[1]);
  const [character, setCharacter] = useState<CharacterPreset>(INITIAL_CHARACTERS[0]);
  const [year, setYear] = useState(1);

  // Financial & Emotional Core
  const [cash, setCash] = useState(1600000);
  const [joy, setJoy] = useState(75);
  const [annualSalary, setAnnualSalary] = useState(1200000);
  const [mandatoryExpensesCost, setMandatoryExpensesCost] = useState(420000);
  const [isMandatoryExpensesPaid, setIsMandatoryExpensesPaid] = useState(false);

  // Economy & Rates
  const [inflationRate, setInflationRate] = useState(0.08); // 8%
  const [keyRate, setKeyRate] = useState(0.12); // 12%
  const [currentNews, setCurrentNews] = useState<MacroNews>(MACRO_NEWS_POOL[0]);
  const [activeCrisis, setActiveCrisis] = useState<MacroNews | null>(null);
  const [isGeneratingAiNews, setIsGeneratingAiNews] = useState(false);
  const [newsHistory, setNewsHistory] = useState<
    { year: number; news: MacroNews; inflation: number; keyRate: number }[]
  >([]);

  // Assets
  const [stocks, setStocks] = useState<StockAsset[]>(INITIAL_STOCKS);
  const [bonds, setBonds] = useState<BondAsset[]>(INITIAL_BONDS);
  const [deposits, setDeposits] = useState<BankDeposit[]>([]);
  const [crypto, setCrypto] = useState<CryptoAsset[]>(INITIAL_CRYPTO);
  const [businessAssets, setBusinessAssets] = useState<BusinessOrRealEstate[]>(INITIAL_BUSINESS_AND_REAL_ESTATE);
  const [insurances, setInsurances] = useState<InsurancePolicy[]>(INITIAL_INSURANCES);
  const [educationTiers, setEducationTiers] = useState<EducationTier[]>(INITIAL_EDUCATION_TIERS);

  // Banking & Debt
  const [loans, setLoans] = useState<Loan[]>([]);
  const [creditCard, setCreditCard] = useState<CreditCard>({
    limit: 600000,
    usedAmount: 0,
    gracePeriodYearsRemaining: 1,
    interestRate: 0.28,
    penaltyRate: 0.1,
    isOverdue: false,
  });
  const [debitCard, setDebitCard] = useState<DebitCard>({
    active: false,
    name: 'Кэшбэк Карта 3%',
    cashbackRate: 0.03,
    annualFee: 1500,
    benefitDescription: '3% возврат со всех покупок',
  });

  // Turn Expenses Selection
  const [optionalExpenses, setOptionalExpenses] = useState<OptionalExpense[]>([
    OPTIONAL_EXPENSES_POOL[0],
    OPTIONAL_EXPENSES_POOL[1],
    OPTIONAL_EXPENSES_POOL[2],
  ]);
  const [acceptedOptionalIds, setAcceptedOptionalIds] = useState<string[]>([]);
  const [declinedOptionalIds, setDeclinedOptionalIds] = useState<string[]>([]);

  // State Tracking for Reports & Leaderboard
  const [lastTurnReport, setLastTurnReport] = useState<TurnReport | null>(null);
  const [currentEvent, setCurrentEvent] = useState<GameRandomEvent | null>(null);
  const [eventInsuranceSaved, setEventInsuranceSaved] = useState(false);
  const [pendingTaxRefund, setPendingTaxRefund] = useState(0);

  // Lifetime Stats
  const [totalDividendsEarned, setTotalDividendsEarned] = useState(0);
  const [totalCouponsEarned, setTotalCouponsEarned] = useState(0);
  const [totalSalaryEarned, setTotalSalaryEarned] = useState(1200000);
  const [history, setHistory] = useState<YearHistoryPoint[]>([
    {
      year: 1,
      netWorth: 350000,
      cash: 350000,
      invested: 0,
      joy: 75,
      passiveIncome: 0,
    },
  ]);

  // Game End State
  const [isVictorious, setIsVictorious] = useState(false);
  const [failReason, setFailReason] = useState<string | undefined>();
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);

  // Computed Values
  const stocksValue = useMemo(
    () => stocks.reduce((acc, s) => acc + s.ownedShares * s.price, 0),
    [stocks]
  );
  const bondsValue = useMemo(
    () => bonds.reduce((acc, b) => acc + b.ownedCount * b.faceValue, 0),
    [bonds]
  );
  const depositsValue = useMemo(
    () => deposits.reduce((acc, d) => acc + d.currentAmount, 0),
    [deposits]
  );
  const cryptoValue = useMemo(
    () => crypto.reduce((acc, c) => acc + Math.round(c.ownedAmount * c.price), 0),
    [crypto]
  );
  const businessValue = useMemo(
    () => businessAssets.filter((a) => a.owned).reduce((acc, a) => acc + a.cost, 0),
    [businessAssets]
  );
  const investedAmount = useMemo(
    () => stocksValue + bondsValue + depositsValue + cryptoValue + businessValue,
    [stocksValue, bondsValue, depositsValue, cryptoValue, businessValue]
  );
  const debtTotal = useMemo(
    () => loans.reduce((acc, l) => acc + l.remainingDebt, 0) + creditCard.usedAmount,
    [loans, creditCard]
  );
  const netWorth = useMemo(
    () => Math.max(0, cash + investedAmount - debtTotal),
    [cash, investedAmount, debtTotal]
  );

  const hasCar = useMemo(
    () => acceptedOptionalIds.includes('opt_car_purchase'),
    [acceptedOptionalIds]
  );
  const hasApartment = useMemo(
    () => acceptedOptionalIds.includes('opt_own_apartment'),
    [acceptedOptionalIds]
  );
  const hasBusiness = useMemo(
    () => businessAssets.some((a) => a.type === 'BUSINESS' && a.owned),
    [businessAssets]
  );

  const passiveIncomeAnnual = useMemo(() => {
    const stockDivs = stocks.reduce((acc, s) => acc + s.ownedShares * s.price * s.dividendYield, 0);
    const bondCoupons = bonds.reduce((acc, b) => acc + b.ownedCount * b.faceValue * b.couponRate, 0);
    const businessIncome = businessAssets
      .filter((a) => a.owned)
      .reduce((acc, a) => acc + a.cost * a.annualIncomeRate, 0);
    return Math.round(stockDivs + bondCoupons + businessIncome);
  }, [stocks, bonds, businessAssets]);

  const emergencyFundMonths = useMemo(() => {
    const monthlyExpenses = mandatoryExpensesCost / 12;
    return monthlyExpenses > 0 ? cash / monthlyExpenses : 0;
  }, [cash, mandatoryExpensesCost]);

  // Dynamic calculation of mandatory expenses breakdown with taxes & lifestyle inflation
  const mandatoryBreakdown = useMemo(() => {
    return calculateMandatoryExpensesBreakdown({
      annualSalary,
      baseLivingFloor: 160000,
      hasApartment,
      hasCar,
      debitCardActive: debitCard.active,
      inflationMultiplier: Math.pow(1 + inflationRate, Math.min(10, year - 1)),
    });
  }, [annualSalary, hasApartment, hasCar, debitCard.active, inflationRate, year]);

  useEffect(() => {
    setMandatoryExpensesCost(mandatoryBreakdown.total);
  }, [mandatoryBreakdown.total]);

  // Load Saved Game & Leaderboard
  useEffect(() => {
    try {
      const savedLb = localStorage.getItem(LEADERBOARD_KEY);
      if (savedLb) {
        setLeaderboard(JSON.parse(savedLb));
      }

      const savedGame = localStorage.getItem(STORAGE_KEY);
      if (savedGame) {
        const data = JSON.parse(savedGame);
        setPlayerName(data.playerName || 'Инвестор');
        setGameMode(data.gameMode || 'GOAL');
        setGoal(data.goal || INITIAL_LIFE_GOALS[1]);
        setCharacter(data.character || INITIAL_CHARACTERS[0]);
        setYear(data.year || 1);
        let loadedCash = data.cash ?? 1600000;
        const loadedMandatory = data.mandatoryExpensesCost || 420000;
        // Auto-heal: If saved game has less cash than mandatory expenses on year 1, credit starting budget
        if (data.year === 1 && !data.isMandatoryExpensesPaid && loadedCash < loadedMandatory) {
          loadedCash += data.annualSalary || 1200000;
        }
        setCash(loadedCash);
        setJoy(data.joy ?? 75);
        setAnnualSalary(data.annualSalary || 1200000);
        setMandatoryExpensesCost(loadedMandatory);
        setIsMandatoryExpensesPaid(data.isMandatoryExpensesPaid || false);
        setInflationRate(data.inflationRate || 0.08);
        setKeyRate(data.keyRate || 0.12);
        setCurrentNews(data.currentNews || MACRO_NEWS_POOL[0]);
        setNewsHistory(data.newsHistory || []);
        const savedStocks = data.stocks || [];
        const mergedStocks = INITIAL_STOCKS.map((initS) => {
          const found = savedStocks.find((s: StockAsset) => s.id === initS.id);
          return found || initS;
        });
        setStocks(mergedStocks);
        setBonds(data.bonds || INITIAL_BONDS);
        setDeposits(data.deposits || []);
        setCrypto(data.crypto || INITIAL_CRYPTO);
        setBusinessAssets(data.businessAssets || INITIAL_BUSINESS_AND_REAL_ESTATE);
        setInsurances(data.insurances || INITIAL_INSURANCES);
        setEducationTiers(data.educationTiers || INITIAL_EDUCATION_TIERS);
        setLoans(data.loans || []);
        setCreditCard(data.creditCard || { limit: 600000, usedAmount: 0, gracePeriodYearsRemaining: 1, interestRate: 0.28, penaltyRate: 0.1, isOverdue: false });
        setDebitCard(data.debitCard || { active: false, name: 'Кэшбэк Карта 3%', cashbackRate: 0.03, annualFee: 1500, benefitDescription: '' });
        setOptionalExpenses(data.optionalExpenses || [OPTIONAL_EXPENSES_POOL[0], OPTIONAL_EXPENSES_POOL[1]]);
        setAcceptedOptionalIds(data.acceptedOptionalIds || []);
        setDeclinedOptionalIds(data.declinedOptionalIds || []);
        setTotalDividendsEarned(data.totalDividendsEarned || 0);
        setTotalCouponsEarned(data.totalCouponsEarned || 0);
        setTotalSalaryEarned(data.totalSalaryEarned || 1200000);
        setHistory(data.history || [{ year: 1, netWorth: 350000, cash: 350000, invested: 0, joy: 75, passiveIncome: 0 }]);
      } else {
        // Open setup modal on first launch
        setIsSetupOpen(true);
      }

      // Check if onboarding tour has been completed
      const tourDone = localStorage.getItem('finlife_tour_completed');
      if (!tourDone) {
        setIsTourOpen(true);
      }
    } catch {
      setIsSetupOpen(true);
    }
  }, []);

  // Save Game on State Change
  const saveCurrentGame = useCallback(() => {
    try {
      const data = {
        playerName,
        gameMode,
        goal,
        character,
        year,
        cash,
        joy,
        annualSalary,
        mandatoryExpensesCost,
        isMandatoryExpensesPaid,
        inflationRate,
        keyRate,
        currentNews,
        newsHistory,
        stocks,
        bonds,
        deposits,
        crypto,
        businessAssets,
        insurances,
        educationTiers,
        loans,
        creditCard,
        debitCard,
        optionalExpenses,
        acceptedOptionalIds,
        declinedOptionalIds,
        totalDividendsEarned,
        totalCouponsEarned,
        totalSalaryEarned,
        history,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // ignore
    }
  }, [
    playerName, gameMode, goal, character, year, cash, joy, annualSalary,
    mandatoryExpensesCost, isMandatoryExpensesPaid, inflationRate, keyRate,
    currentNews, newsHistory, stocks, bonds, deposits, crypto, businessAssets,
    insurances, educationTiers, loans, creditCard, debitCard, optionalExpenses,
    acceptedOptionalIds, declinedOptionalIds, totalDividendsEarned, totalCouponsEarned,
    totalSalaryEarned, history,
  ]);

  useEffect(() => {
    saveCurrentGame();
  }, [saveCurrentGame]);

  // Start New Game Handler
  const handleStartGame = (params: {
    playerName: string;
    character: CharacterPreset;
    mode: GameMode;
    goal: LifeGoal;
  }) => {
    setPlayerName(params.playerName);
    setCharacter(params.character);
    setGameMode(params.mode);
    setGoal(params.goal);
    setYear(1);

    const initialSalary = params.character.initialSalary;
    setAnnualSalary(initialSalary);
    setCash(params.character.initialCash);
    setJoy(params.character.initialJoy);

    const baseMandatory = Math.round(initialSalary * 0.35);
    setMandatoryExpensesCost(baseMandatory);
    setIsMandatoryExpensesPaid(false);

    setStocks(INITIAL_STOCKS.map((s) => ({ ...s, ownedShares: 0 })));
    setBonds(INITIAL_BONDS.map((b) => ({ ...b, ownedCount: 0 })));
    setDeposits([]);
    setCrypto(INITIAL_CRYPTO.map((c) => ({ ...c, ownedAmount: 0 })));
    setBusinessAssets(INITIAL_BUSINESS_AND_REAL_ESTATE.map((b) => ({ ...b, owned: false })));
    setInsurances(INITIAL_INSURANCES.map((i) => ({ ...i, active: false })));
    setEducationTiers(INITIAL_EDUCATION_TIERS.map((e) => ({ ...e, completed: false })));
    setLoans([]);
    setCreditCard({
      limit: Math.round(initialSalary * 0.5),
      usedAmount: 0,
      gracePeriodYearsRemaining: 1,
      interestRate: 0.28,
      penaltyRate: 0.1,
      isOverdue: false,
    });
    setDebitCard({
      active: false,
      name: 'Кэшбэк Карта 3%',
      cashbackRate: 0.03,
      annualFee: 1500,
      benefitDescription: '3% возврат со всех покупок',
    });

    setOptionalExpenses([
      OPTIONAL_EXPENSES_POOL[0],
      OPTIONAL_EXPENSES_POOL[1],
      OPTIONAL_EXPENSES_POOL[2],
    ]);
    setAcceptedOptionalIds([]);
    setDeclinedOptionalIds([]);

    setInflationRate(0.08);
    setKeyRate(0.12);
    setCurrentNews(MACRO_NEWS_POOL[0]);
    setNewsHistory([]);
    setTotalDividendsEarned(0);
    setTotalCouponsEarned(0);
    setTotalSalaryEarned(initialSalary);

    setHistory([
      {
        year: 1,
        netWorth: params.character.initialCash,
        cash: params.character.initialCash,
        invested: 0,
        joy: params.character.initialJoy,
        passiveIncome: 0,
      },
    ]);

    setIsSetupOpen(false);
    setIsGameOverOpen(false);
    localStorage.removeItem(STORAGE_KEY);
  };

  // Pay Mandatory Expenses
  const handlePayMandatoryExpenses = (useCreditCard: boolean = false) => {
    if (useCreditCard) {
      const availableCredit = creditCard.limit - creditCard.usedAmount;
      if (availableCredit >= mandatoryExpensesCost) {
        setCreditCard((prev) => ({
          ...prev,
          usedAmount: prev.usedAmount + mandatoryExpensesCost,
        }));
        setIsMandatoryExpensesPaid(true);
        sound.playCoin();
      }
      return;
    }

    if (cash < mandatoryExpensesCost) return;
    setCash((prev) => prev - mandatoryExpensesCost);
    setIsMandatoryExpensesPaid(true);
    sound.playCoin();
  };

  // Accept Optional Expense
  const handleAcceptOptional = (expense: OptionalExpense) => {
    if (cash < expense.cost) return;
    setCash((prev) => prev - expense.cost);
    setJoy((prev) => Math.min(100, Math.max(0, prev + expense.joyDeltaIfAccepted)));
    setAcceptedOptionalIds((prev) => [...prev, expense.id]);

    // Permanent cost adjustment (e.g. car maintenance or apartment savings)
    if (expense.permanentAnnualCostDelta) {
      setMandatoryExpensesCost((prev) => Math.max(100000, prev + expense.permanentAnnualCostDelta!));
    }
  };

  // Decline Optional Expense
  const handleDeclineOptional = (expense: OptionalExpense) => {
    setJoy((prev) => Math.min(100, Math.max(0, prev + expense.joyDeltaIfDeclined)));
    setDeclinedOptionalIds((prev) => [...prev, expense.id]);
  };

  // Toggle Insurance
  const handleToggleInsurance = (type: 'HEALTH_DMS' | 'HOME' | 'CAR_CASCO') => {
    const policy = insurances.find((i) => i.type === type);
    if (!policy) return;

    if (policy.active) {
      // Deactivate
      setInsurances((prev) =>
        prev.map((i) => (i.type === type ? { ...i, active: false } : i))
      );
    } else {
      // Activate
      if (cash < policy.annualCost) return;
      setCash((prev) => prev - policy.annualCost);
      setInsurances((prev) =>
        prev.map((i) => (i.type === type ? { ...i, active: true } : i))
      );
    }
  };

  // Buy / Sell Stocks
  const handleBuyStock = (stockId: string, count: number) => {
    const stock = stocks.find((s) => s.id === stockId);
    if (!stock) return;
    const cost = stock.price * count;
    if (cash < cost) return;

    setCash((prev) => prev - cost);
    setStocks((prev) =>
      prev.map((s) => (s.id === stockId ? { ...s, ownedShares: s.ownedShares + count } : s))
    );
  };

  const handleSellStock = (stockId: string, count: number) => {
    const stock = stocks.find((s) => s.id === stockId);
    if (!stock || stock.ownedShares < count) return;
    const revenue = stock.price * count;

    setCash((prev) => prev + revenue);
    setStocks((prev) =>
      prev.map((s) => (s.id === stockId ? { ...s, ownedShares: s.ownedShares - count } : s))
    );
  };

  // Buy / Sell Bonds
  const handleBuyBond = (bondId: string, count: number) => {
    const bond = bonds.find((b) => b.id === bondId);
    if (!bond) return;
    const cost = bond.faceValue * count;
    if (cash < cost) return;

    setCash((prev) => prev - cost);
    setBonds((prev) =>
      prev.map((b) => (b.id === bondId ? { ...b, ownedCount: b.ownedCount + count } : b))
    );
  };

  const handleSellBond = (bondId: string, count: number) => {
    const bond = bonds.find((b) => b.id === bondId);
    if (!bond || bond.ownedCount < count) return;
    const revenue = bond.faceValue * count;

    setCash((prev) => prev + revenue);
    setBonds((prev) =>
      prev.map((b) => (b.id === bondId ? { ...b, ownedCount: b.ownedCount - count } : b))
    );
  };

  // Bank Deposits
  const handleOpenDeposit = (params: {
    bankName: string;
    bankType: 'STATE_TOP' | 'REGIONAL' | 'NEOBANK';
    interestRate: number;
    termYears: number;
    amount: number;
  }) => {
    if (cash < params.amount) return;
    setCash((prev) => prev - params.amount);
    const newDep: BankDeposit = {
      id: `dep_${Date.now()}`,
      bankName: params.bankName,
      bankType: params.bankType,
      interestRate: params.interestRate,
      termYears: params.termYears,
      startYear: year,
      principal: params.amount,
      currentAmount: params.amount,
      isInsuredAsv: true,
    };
    setDeposits((prev) => [...prev, newDep]);
  };

  const handleCloseDepositEarly = (depositId: string) => {
    const dep = deposits.find((d) => d.id === depositId);
    if (!dep) return;
    // Interest forfeited on early closure as per screenshot IMG_9108!
    setCash((prev) => prev + dep.principal);
    setDeposits((prev) => prev.filter((d) => d.id !== depositId));
  };

  // Crypto
  const handleBuyCrypto = (cryptoId: string, rubleAmount: number) => {
    const coin = crypto.find((c) => c.id === cryptoId);
    if (!coin || cash < rubleAmount) return;
    const coinsPurchased = rubleAmount / coin.price;

    setCash((prev) => prev - rubleAmount);
    setCrypto((prev) =>
      prev.map((c) =>
        c.id === cryptoId ? { ...c, ownedAmount: c.ownedAmount + coinsPurchased } : c
      )
    );
  };

  const handleSellCrypto = (cryptoId: string, rubleAmount: number) => {
    const coin = crypto.find((c) => c.id === cryptoId);
    if (!coin) return;
    const coinsToSell = rubleAmount / coin.price;
    if (coin.ownedAmount < coinsToSell) return;

    setCash((prev) => prev + rubleAmount);
    setCrypto((prev) =>
      prev.map((c) =>
        c.id === cryptoId ? { ...c, ownedAmount: Math.max(0, c.ownedAmount - coinsToSell) } : c
      )
    );
  };

  // Real estate & Business
  const handleBuyBusinessAsset = (assetId: string) => {
    const asset = businessAssets.find((a) => a.id === assetId);
    if (!asset || cash < asset.cost || asset.owned) return;

    setCash((prev) => prev - asset.cost);
    setBusinessAssets((prev) =>
      prev.map((a) => (a.id === assetId ? { ...a, owned: true } : a))
    );
    setJoy((prev) => Math.min(100, prev + 15));
  };

  // Education
  const handleCompleteEducation = (tierId: string) => {
    const tier = educationTiers.find((t) => t.id === tierId);
    if (!tier || cash < tier.cost || tier.completed) return;

    setCash((prev) => prev - tier.cost);
    setJoy((prev) => Math.min(100, prev + tier.joyBonus));
    setAnnualSalary((prev) => Math.round(prev * (1 + tier.salaryBonusMultiplier)));
    setEducationTiers((prev) =>
      prev.map((t) => (t.id === tierId ? { ...t, completed: true } : t))
    );
    // 13% tax refund credited in the next turn!
    setPendingTaxRefund((prev) => prev + Math.round(tier.cost * 0.13));
  };

  // Loans
  const handleTakeLoan = (amount: number, termYears: number, interestRate: number) => {
    const r = interestRate;
    const n = termYears;
    const annuityFactor = (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const annualPayment = Math.round(amount * annuityFactor);

    const newLoan: Loan = {
      id: `loan_${Date.now()}`,
      bankName: 'Сбербанк',
      totalAmount: amount,
      remainingDebt: amount,
      annualInterestRate: interestRate,
      annualPayment,
      durationYears: termYears,
      yearsRemaining: termYears,
    };

    setCash((prev) => prev + amount);
    setLoans((prev) => [...prev, newLoan]);
  };

  // Credit Card Operations
  const handleUseCreditCard = (amount: number) => {
    const available = creditCard.limit - creditCard.usedAmount;
    const borrow = Math.min(amount, available);
    if (borrow <= 0) return;

    setCash((prev) => prev + borrow);
    setCreditCard((prev) => ({
      ...prev,
      usedAmount: prev.usedAmount + borrow,
      gracePeriodYearsRemaining: 1, // grace active for this turn
      isOverdue: false,
    }));
  };

  const handleRepayCreditCard = (amount: number) => {
    const repay = Math.min(amount, creditCard.usedAmount, cash);
    if (repay <= 0) return;

    setCash((prev) => prev - repay);
    setCreditCard((prev) => ({
      ...prev,
      usedAmount: prev.usedAmount - repay,
      isOverdue: prev.usedAmount - repay > 0 ? prev.isOverdue : false,
    }));
  };

  // Debit Card Toggle
  const handleToggleDebitCard = () => {
    if (debitCard.active) {
      setDebitCard((prev) => ({ ...prev, active: false }));
    } else {
      if (cash < debitCard.annualFee) return;
      setCash((prev) => prev - debitCard.annualFee);
      setDebitCard((prev) => ({ ...prev, active: true }));
    }
  };

  // Record Game Result in Leaderboard
  const recordLeaderboard = useCallback((victorious: boolean, reason?: string) => {
    const newEntry: LeaderboardEntry = {
      id: `lead_${Date.now()}`,
      playerName,
      mode: gameMode,
      goalTitle: goal.title,
      finalCapital: netWorth,
      finalJoy: joy,
      yearsTaken: year,
      isVictorious: victorious,
      timestamp: Date.now(),
    };

    setLeaderboard((prev) => {
      // Keep best per player name or add
      const filtered = prev.filter((e) => e.playerName !== playerName || e.finalCapital < netWorth);
      const updated = [newEntry, ...filtered];
      localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(updated));
      return updated;
    });

    setIsVictorious(victorious);
    setFailReason(reason);
    setIsGameOverOpen(true);
  }, [playerName, gameMode, goal.title, netWorth, joy, year]);

  // Turn Advancement / Advance Year (The Core Engine)
  const handleAdvanceYear = async () => {
    if (!isMandatoryExpensesPaid) return;

    sound.playCoin();

    // 1. Calculate Passive Incomes
    let earnedDividends = 0;
    stocks.forEach((s) => {
      earnedDividends += Math.round(s.ownedShares * s.price * s.dividendYield);
    });

    let earnedCoupons = 0;
    bonds.forEach((b) => {
      earnedCoupons += Math.round(b.ownedCount * b.faceValue * b.couponRate);
    });

    let earnedBusinessIncome = 0;
    businessAssets.forEach((a) => {
      if (a.owned) {
        earnedBusinessIncome += Math.round(a.cost * a.annualIncomeRate);
      }
    });

    // 2. Deposit Interest & Maturing
    let earnedDepositInterest = 0;
    const updatedDeposits: BankDeposit[] = [];
    deposits.forEach((dep) => {
      const yearsPassed = year + 1 - dep.startYear;
      // Capitalization per year
      const interestForYear = Math.round(dep.currentAmount * dep.interestRate);
      earnedDepositInterest += interestForYear;
      const nextAmount = dep.currentAmount + interestForYear;

      if (yearsPassed >= dep.termYears) {
        // Matured! Return money + interest to cash
        setCash((prev) => prev + nextAmount);
      } else {
        updatedDeposits.push({
          ...dep,
          currentAmount: nextAmount,
        });
      }
    });
    setDeposits(updatedDeposits);

    // 3. Bank Loans & Debt Payments
    let totalLoanPayments = 0;
    const updatedLoans: Loan[] = [];
    loans.forEach((loan) => {
      totalLoanPayments += loan.annualPayment;
      const nextDebt = Math.max(0, loan.remainingDebt - (loan.annualPayment - loan.remainingDebt * loan.annualInterestRate));
      if (loan.yearsRemaining > 1) {
        updatedLoans.push({
          ...loan,
          remainingDebt: Math.round(nextDebt),
          yearsRemaining: loan.yearsRemaining - 1,
        });
      }
    });
    setLoans(updatedLoans);

    // 4. Credit Card Interest & Grace Period Check (IMG_9115)
    let creditCardInterestPaid = 0;
    let nextCreditCard = { ...creditCard };
    if (nextCreditCard.usedAmount > 0) {
      if (nextCreditCard.gracePeriodYearsRemaining > 0) {
        // Inside grace period: no interest this turn, but next turn grace expires!
        nextCreditCard.gracePeriodYearsRemaining = 0;
      } else {
        // Overdue! Apply interest + penalty as in screenshot IMG_9115
        const interest = Math.round(nextCreditCard.usedAmount * nextCreditCard.interestRate);
        const penalty = Math.round(nextCreditCard.usedAmount * nextCreditCard.penaltyRate);
        creditCardInterestPaid = interest + penalty;
        nextCreditCard.usedAmount += interest + penalty;
        nextCreditCard.isOverdue = true;
      }
    }
    setCreditCard(nextCreditCard);

    // 5. Debit card cashback
    const totalSpentThisYear =
      mandatoryExpensesCost +
      optionalExpenses
        .filter((e) => acceptedOptionalIds.includes(e.id))
        .reduce((acc, e) => acc + e.cost, 0);

    const cashbackEarned = debitCard.active
      ? Math.round(totalSpentThisYear * debitCard.cashbackRate)
      : 0;

    // 6. Tax Deductions
    const taxDeductionEarned = pendingTaxRefund;
    setPendingTaxRefund(0); // reset for next year

    // 7. Random Event Generator (AI-Driven or Procedural)
    let chosenEvent: GameRandomEvent;
    if (autoAiEnabled) {
      try {
        chosenEvent = await requestAiGameplayEvent({
          characterName: character.name,
          role: character.role,
          year: year + 1,
          cash,
          netWorth,
          annualSalary,
          joy,
          hasCar,
          hasApartment,
          hasBusiness,
          activeCrisisTitle: activeCrisis?.headline,
        });
      } catch {
        const eligibleEvents = RANDOM_EVENTS_POOL.filter((ev) => {
          if (ev.requiresCar && !hasCar) return false;
          if (ev.requiresApartment && !hasApartment) return false;
          return true;
        });
        chosenEvent = eligibleEvents[Math.floor(Math.random() * eligibleEvents.length)] || RANDOM_EVENTS_POOL[0];
      }
    } else {
      const eligibleEvents = RANDOM_EVENTS_POOL.filter((ev) => {
        if (ev.requiresCar && !hasCar) return false;
        if (ev.requiresApartment && !hasApartment) return false;
        return true;
      });
      chosenEvent = eligibleEvents[Math.floor(Math.random() * eligibleEvents.length)] || RANDOM_EVENTS_POOL[0];
    }
    setCurrentEvent(chosenEvent);

    // Check insurance coverage for event
    let eventLossAfterInsurance = chosenEvent.choices && chosenEvent.choices.length > 0 ? 0 : chosenEvent.cashDelta;
    let insuranceSaved = false;
    if (chosenEvent.coveredByInsurance) {
      const activePolicy = insurances.find(
        (i) => i.type === chosenEvent.coveredByInsurance && i.active
      );
      if (activePolicy) {
        insuranceSaved = true;
        eventLossAfterInsurance = 0;
      }
    }
    setEventInsuranceSaved(insuranceSaved);
    setIsEventModalOpen(true);

    // 8. Update Macro Economy & News with Multi-Year Crisis Lifecycle
    let nextNews: MacroNews;

    if (activeCrisis && activeCrisis.yearsRemaining && activeCrisis.yearsRemaining > 1) {
      // Continuing multi-year crisis
      const rem = activeCrisis.yearsRemaining - 1;
      nextNews = {
        ...activeCrisis,
        yearsRemaining: rem,
        summary: `[Идет ${activeCrisis.durationYears! - rem + 1}-й год из ${activeCrisis.durationYears}]: ${activeCrisis.summary}`,
      };
      setActiveCrisis(nextNews);
    } else if (activeCrisis && activeCrisis.yearsRemaining === 1) {
      // Crisis resolved! Transition to recovery
      nextNews = {
        id: `recovery_${Date.now()}`,
        headline: `Окончание кризиса «${activeCrisis.headline}» & Восстановление`,
        summary: 'Острая фаза кризиса успешно преодолена. Деловая активность в стране восстанавливается, ключевая ставка стабилизируется, а котировки акций переходят к росту.',
        inflationDelta: -0.02,
        keyRateDelta: -0.02,
        durationYears: 1,
        yearsRemaining: 1,
        cycleType: 'BOOM',
        gameplayAdvice: 'Период восстановления — идеальный момент для расширения бизнеса и вложений в реальные активы.',
        marketImpact: {
          stockMarketMultiplier: 1.18,
          cryptoMultiplier: 1.30,
          favoredSector: 'Финансы & Финтех',
          salaryMultiplier: 1.05,
          businessMultiplier: 1.15,
        },
      };
      setActiveCrisis(null);
    } else {
      if (autoAiEnabled) {
        try {
          nextNews = await requestAiMacroNews({
            year: year + 1,
            inflationRate,
            keyRate,
            requestedType: 'RANDOM',
          });
          if (nextNews.durationYears && nextNews.durationYears > 1) {
            setActiveCrisis(nextNews);
          }
        } catch {
          const triggerMultiYear = Math.random() < 0.35;
          if (triggerMultiYear) {
            const randDuration = (Math.floor(Math.random() * 3) + 1) as 1 | 2 | 3;
            const crisisPool = [
              {
                headline: 'Банковский кризис ликвидности',
                summary: 'Кредитные риски вынуждают банки ужесточать требования. ЦБ повышает ставку, депозиты дают рекордную доходность.',
                cycleType: 'CRISIS' as const,
                inflationDelta: 0.04,
                keyRateDelta: 0.04,
                gameplayAdvice: 'Открывайте долгосрочные вклады под высокий процент и скупайте дивидендные акции на спаде.',
                marketImpact: { stockMarketMultiplier: 0.75, cryptoMultiplier: 0.60, favoredSector: 'Потребительский', hitSector: 'Финансы & Финтех' },
              },
              {
                headline: 'Сырьевой суперцикл: рекордный рост цен на нефть и металлы',
                summary: 'Дефицит сырья на мировых биржах вызвал мощный приток валюты в экономику. Доходы сырьевых гигантов бьют рекорды.',
                cycleType: 'BOOM' as const,
                inflationDelta: -0.015,
                keyRateDelta: -0.02,
                gameplayAdvice: 'Акции нефтяных и металлургических компаний платят рекордные дивиденды.',
                marketImpact: { stockMarketMultiplier: 1.30, cryptoMultiplier: 1.35, favoredSector: 'Нефть & Газ', hitSector: 'Девелопмент' },
              },
              {
                headline: 'Технологический бум и интеграция ИИ',
                summary: 'Масштабное внедрение нейросетей увеличило производительность труда. Сектор технологий привлекает рекордные инвестиции.',
                cycleType: 'TECH_RALLY' as const,
                inflationDelta: -0.01,
                keyRateDelta: -0.01,
                gameplayAdvice: 'Инвестиции в профильное образование окупаются быстрее, а IT-акции показывают взрывной рост.',
                marketImpact: { stockMarketMultiplier: 1.25, cryptoMultiplier: 1.60, favoredSector: 'IT & ИИ', hitSector: 'Металлургия' },
              },
            ];
            const picked = crisisPool[Math.floor(Math.random() * crisisPool.length)];
            nextNews = {
              id: `macro_${Date.now()}`,
              headline: picked.headline,
              summary: picked.summary,
              durationYears: randDuration,
              yearsRemaining: randDuration,
              cycleType: picked.cycleType,
              inflationDelta: picked.inflationDelta,
              keyRateDelta: picked.keyRateDelta,
              gameplayAdvice: picked.gameplayAdvice,
              marketImpact: picked.marketImpact,
            };
            if (randDuration > 1) {
              setActiveCrisis(nextNews);
            }
          } else {
            const nextNewsIndex = year % MACRO_NEWS_POOL.length;
            nextNews = { ...MACRO_NEWS_POOL[nextNewsIndex], durationYears: 1, yearsRemaining: 1 };
          }
        }
      } else {
        // Procedural generator
        const triggerMultiYear = Math.random() < 0.35;
        if (triggerMultiYear) {
          const randDuration = (Math.floor(Math.random() * 3) + 1) as 1 | 2 | 3;
          const crisisPool = [
            {
              headline: 'Банковский кризис ликвидности',
              summary: 'Кредитные риски вынуждают банки ужесточать требования. ЦБ повышает ставку, депозиты дают рекордную доходность.',
              cycleType: 'CRISIS' as const,
              inflationDelta: 0.04,
              keyRateDelta: 0.04,
              gameplayAdvice: 'Открывайте долгосрочные вклады под высокий процент и скупайте дивидендные акции на спаде.',
              marketImpact: { stockMarketMultiplier: 0.75, cryptoMultiplier: 0.60, favoredSector: 'Потребительский', hitSector: 'Финансы & Финтех' },
            },
            {
              headline: 'Сырьевой суперцикл: рекордный рост цен на нефть и металлы',
              summary: 'Дефицит сырья на мировых биржах вызвал мощный приток валюты в экономику. Доходы сырьевых гигантов бьют рекорды.',
              cycleType: 'BOOM' as const,
              inflationDelta: -0.015,
              keyRateDelta: -0.02,
              gameplayAdvice: 'Акции нефтяных и металлургических компаний платят рекордные дивиденды.',
              marketImpact: { stockMarketMultiplier: 1.30, cryptoMultiplier: 1.35, favoredSector: 'Нефть & Газ', hitSector: 'Девелопмент' },
            },
            {
              headline: 'Технологический бум и интеграция ИИ',
              summary: 'Масштабное внедрение нейросетей увеличило производительность труда. Сектор технологий привлекает рекордные инвестиции.',
              cycleType: 'TECH_RALLY' as const,
              inflationDelta: -0.01,
              keyRateDelta: -0.01,
              gameplayAdvice: 'Инвестиции в профильное образование окупаются быстрее, а IT-акции показывают взрывной рост.',
              marketImpact: { stockMarketMultiplier: 1.25, cryptoMultiplier: 1.60, favoredSector: 'IT & ИИ', hitSector: 'Металлургия' },
            },
          ];
          const picked = crisisPool[Math.floor(Math.random() * crisisPool.length)];
          nextNews = {
            id: `macro_${Date.now()}`,
            headline: picked.headline,
            summary: picked.summary,
            durationYears: randDuration,
            yearsRemaining: randDuration,
            cycleType: picked.cycleType,
            inflationDelta: picked.inflationDelta,
            keyRateDelta: picked.keyRateDelta,
            gameplayAdvice: picked.gameplayAdvice,
            marketImpact: picked.marketImpact,
          };
          if (randDuration > 1) {
            setActiveCrisis(nextNews);
          }
        } else {
          const nextNewsIndex = year % MACRO_NEWS_POOL.length;
          nextNews = { ...MACRO_NEWS_POOL[nextNewsIndex], durationYears: 1, yearsRemaining: 1 };
        }
      }
    }

    setNewsHistory((prev) => [
      { year, news: currentNews, inflation: inflationRate, keyRate },
      ...prev,
    ]);
    setCurrentNews(nextNews);

    const nextInflation = Math.max(0.04, Math.min(0.18, inflationRate + nextNews.inflationDelta));
    const nextKeyRate = Math.max(0.075, Math.min(0.21, keyRate + nextNews.keyRateDelta));
    setInflationRate(nextInflation);
    setKeyRate(nextKeyRate);

    // 9. Update Stock & Crypto Prices with News multipliers and randomness
    setStocks((prev) =>
      prev.map((stock) => {
        const sectorFavored = nextNews.marketImpact.favoredSector === stock.sector;
        const sectorHit = nextNews.marketImpact.hitSector === stock.sector;
        const sectorBonus = sectorFavored ? 0.15 : sectorHit ? -0.20 : 0;
        const randomFactor = (Math.random() * 0.2 - 0.1); // -10% to +10%
        const multiplier = Math.max(0.4, nextNews.marketImpact.stockMarketMultiplier + sectorBonus + randomFactor);
        const newPrice = Math.max(10, Math.round(stock.price * multiplier));
        return {
          ...stock,
          prevPrice: stock.price,
          price: newPrice,
          history: [...stock.history, newPrice].slice(-6),
        };
      })
    );

    setCrypto((prev) =>
      prev.map((coin) => {
        const randomFactor = (Math.random() * 0.8 - 0.4); // -40% to +40%
        const multiplier = nextNews.marketImpact.cryptoMultiplier + randomFactor;
        const newPrice = Math.max(1, Math.round(coin.price * multiplier));
        return {
          ...coin,
          prevPrice: coin.price,
          price: newPrice,
          history: [...coin.history, newPrice].slice(-6),
        };
      })
    );

    // 10. Net Cash Delta and Net Worth
    const netCashChange =
      annualSalary +
      earnedBusinessIncome +
      earnedDividends +
      earnedCoupons +
      cashbackEarned +
      taxDeductionEarned -
      totalLoanPayments +
      eventLossAfterInsurance;

    const nextCash = Math.max(0, cash + netCashChange);
    setCash(nextCash);

    // Joy Delta
    // Natural routine joy decay: -5 points per year, offset by events & state
    let joyChange = -5 + chosenEvent.joyDelta;
    if (cash > annualSalary * 2) joyChange += 3; // sense of security
    if (joy < 30) joyChange -= 2; // burnout spiral
    const nextJoy = Math.max(0, Math.min(100, joy + joyChange));
    setJoy(nextJoy);

    // Reset Insurances for next year (each policy is valid for 1 year!)
    setInsurances((prev) => prev.map((i) => ({ ...i, active: false })));

    // Mandatory Expenses updated with inflation for next year
    const nextMandatory = Math.round(mandatoryExpensesCost * (1 + nextInflation));
    setMandatoryExpensesCost(nextMandatory);
    setIsMandatoryExpensesPaid(false);

    // Update Lifetime Earnings
    setTotalDividendsEarned((prev) => prev + earnedDividends);
    setTotalCouponsEarned((prev) => prev + earnedCoupons);
    setTotalSalaryEarned((prev) => prev + annualSalary);

    // Refresh Optional Expenses for the new year
    const shuffled = [...OPTIONAL_EXPENSES_POOL]
      .filter((e) => !acceptedOptionalIds.includes(e.id))
      .sort(() => 0.5 - Math.random())
      .slice(0, 3);
    setOptionalExpenses(shuffled);
    setAcceptedOptionalIds([]);
    setDeclinedOptionalIds([]);

    // Turn Report
    const report: TurnReport = {
      year,
      salaryIncome: annualSalary,
      businessIncome: earnedBusinessIncome,
      dividendsEarned: earnedDividends,
      couponsEarned: earnedCoupons,
      depositInterestEarned: earnedDepositInterest,
      cashbackEarned,
      taxDeductionsEarned: taxDeductionEarned,
      mandatoryExpensesPaid: mandatoryExpensesCost,
      optionalExpensesPaid: totalSpentThisYear - mandatoryExpensesCost,
      insurancePaid: insurances.filter((i) => i.active).reduce((acc, i) => acc + i.annualCost, 0),
      cardFeesPaid: debitCard.active ? debitCard.annualFee : 0,
      loanPaymentsPaid: totalLoanPayments,
      creditCardInterestPaid,
      eventsSummary: [
        `${chosenEvent.title}: ${
          insuranceSaved ? 'убыток покрыт страховкой!' : `${chosenEvent.cashDelta >= 0 ? '+' : ''}${chosenEvent.cashDelta} ₽`
        }`,
      ],
      netCashDelta: netCashChange,
      netWorthDelta: nextCash - cash,
      joyDelta: joyChange,
    };
    setLastTurnReport(report);
    setIsTurnSummaryOpen(true);

    // Update History Chart Data
    const nextYear = year + 1;
    setYear(nextYear);
    setHistory((prev) => [
      ...prev,
      {
        year: nextYear,
        netWorth: nextCash + investedAmount - debtTotal,
        cash: nextCash,
        invested: investedAmount,
        joy: nextJoy,
        passiveIncome: passiveIncomeAnnual,
      },
    ]);

    // Check Victory / Game Over for 10_YEARS mode
    if (gameMode === '10_YEARS' && year >= 10) {
      const hasUnpaidCC = nextCreditCard.usedAmount > 0;
      const joyThresholdMet = nextJoy >= 80;
      const won = !hasUnpaidCC && joyThresholdMet;
      let reason: string | undefined;
      if (hasUnpaidCC) {
        reason = 'Нельзя победить с непогашенным долгом по кредитной карте (Правило игры)!';
      } else if (!joyThresholdMet) {
        reason = `Уровень радости составил ${nextJoy}/100 при необходимом минимуме 80 пунктов!`;
      }
      recordLeaderboard(won, reason);
    }
  };

  // Finish Goal Game Early / Triumph
  const handleFinishGameEarly = () => {
    const hasUnpaidCC = creditCard.usedAmount > 0;
    if (hasUnpaidCC) {
      alert('Внимание: Игру нельзя завершить с непогашенным долгом по кредитной карте!');
      return;
    }
    recordLeaderboard(true);
  };

  // AI-Powered Macro Event Generator
  const handleTriggerAiMacroEvent = async (
    type: 'RANDOM' | 'CRISIS' | 'BOOM' | 'STAGFLATION' | 'TECH',
    duration?: 1 | 2 | 3
  ) => {
    setIsGeneratingAiNews(true);
    try {
      const generated = await requestAiMacroNews({
        year,
        inflationRate,
        keyRate,
        requestedType: type,
        requestedDuration: duration,
      });

      setCurrentNews(generated);
      if (generated.durationYears && generated.durationYears > 1) {
        setActiveCrisis(generated);
      }

      // Update inflation & key rate
      const nextInflation = Math.max(0.04, Math.min(0.20, inflationRate + generated.inflationDelta));
      const nextKeyRate = Math.max(0.075, Math.min(0.23, keyRate + generated.keyRateDelta));
      setInflationRate(nextInflation);
      setKeyRate(nextKeyRate);

      // Re-evaluate stock prices with event multiplier
      setStocks((prev) =>
        prev.map((s) => {
          const isFavored = generated.marketImpact.favoredSector === s.sector;
          const isHit = generated.marketImpact.hitSector === s.sector;
          const sectorBonus = isFavored ? 0.15 : isHit ? -0.15 : 0;
          const mult = generated.marketImpact.stockMarketMultiplier + sectorBonus;
          const newPrice = Math.max(10, Math.round(s.price * mult));
          return {
            ...s,
            prevPrice: s.price,
            price: newPrice,
            history: [...s.history, newPrice].slice(-6),
          };
        })
      );
      sound.playSuccess();
    } catch (e) {
      console.error('Failed to trigger AI event:', e);
    } finally {
      setIsGeneratingAiNews(false);
    }
  };

  // On-demand AI Gameplay Event Generator
  const handleTriggerAiGameplayEvent = async () => {
    setIsGeneratingAiNews(true);
    try {
      const event = await requestAiGameplayEvent({
        characterName: character.name,
        role: character.role,
        year,
        cash,
        netWorth,
        annualSalary,
        joy,
        hasCar,
        hasApartment,
        hasBusiness,
        activeCrisisTitle: activeCrisis?.headline,
      });
      setCurrentEvent(event);
      let loss = event.cashDelta;
      let saved = false;
      if (event.coveredByInsurance) {
        const activePolicy = insurances.find(
          (i) => i.type === event.coveredByInsurance && i.active
        );
        if (activePolicy) {
          saved = true;
          loss = 0;
        }
      }
      setEventInsuranceSaved(saved);
      if (!event.choices || event.choices.length === 0) {
        setCash((prev) => Math.max(0, prev + loss));
        setJoy((prev) => Math.max(0, Math.min(100, prev + event.joyDelta)));
      }
      setIsEventModalOpen(true);
      sound.playSuccess();
    } catch (e) {
      console.error('Failed to trigger AI gameplay event:', e);
    } finally {
      setIsGeneratingAiNews(false);
    }
  };

  // Choice selection in interactive event modal
  const handleSelectEventChoice = (choice: EventChoice) => {
    sound.playCoin();
    setCash((prev) => Math.max(0, prev + choice.cashDelta));
    setJoy((prev) => Math.max(0, Math.min(100, prev + choice.joyDelta)));
    setIsEventModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Universal 3-Zone Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenRules={() => setIsRulesOpen(true)}
        onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
        onOpenDownload={() => setIsDownloadOpen(true)}
        onOpenTour={() => setIsTourOpen(true)}
        onRestartGame={() => setIsSetupOpen(true)}
        isMuted={isMuted}
        setIsMuted={setIsMuted}
        year={year}
        gameMode={
          gameMode === '10_YEARS'
            ? 'Классика 10 лет'
            : gameMode === 'SANDBOX'
            ? 'Песочница'
            : goal.title
        }
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 sm:py-6 space-y-5">
        {/* Sleek Unified Dashboard Status Bar */}
        <StatusBar
          character={character}
          year={year}
          maxYears={10}
          mode={gameMode}
          goal={goal}
          cash={cash}
          netWorth={netWorth}
          joy={joy}
          hasApartment={hasApartment}
          hasBusiness={hasBusiness}
          passiveIncome={passiveIncomeAnnual}
          activeCrisis={activeCrisis}
          onFinishGameEarly={handleFinishGameEarly}
        />

        {/* Tab Content Panels */}
        {activeTab === 'overview' && (
          <OverviewTab
            cash={cash}
            netWorth={netWorth}
            annualSalary={annualSalary}
            mandatoryExpensesCost={mandatoryExpensesCost}
            isMandatoryExpensesPaid={isMandatoryExpensesPaid}
            onPayMandatoryExpenses={handlePayMandatoryExpenses}
            optionalExpenses={optionalExpenses}
            acceptedOptionalIds={acceptedOptionalIds}
            declinedOptionalIds={declinedOptionalIds}
            onAcceptOptional={handleAcceptOptional}
            onDeclineOptional={handleDeclineOptional}
            insurances={insurances}
            onToggleInsurance={handleToggleInsurance}
            hasCar={hasCar}
            hasApartment={hasApartment}
            debitCard={debitCard}
            creditCard={creditCard}
            inflationRate={inflationRate}
            onAdvanceYear={handleAdvanceYear}
            year={year}
            emergencyFundMonths={emergencyFundMonths}
            breakdown={mandatoryBreakdown}
          />
        )}

        {activeTab === 'investments' && (
          <InvestmentsTab
            cash={cash}
            stocks={stocks}
            onBuyStock={handleBuyStock}
            onSellStock={handleSellStock}
            bonds={bonds}
            onBuyBond={handleBuyBond}
            onSellBond={handleSellBond}
            deposits={deposits}
            onOpenDeposit={handleOpenDeposit}
            onCloseDepositEarly={handleCloseDepositEarly}
            crypto={crypto}
            onBuyCrypto={handleBuyCrypto}
            onSellCrypto={handleSellCrypto}
            businessAssets={businessAssets}
            onBuyBusinessAsset={handleBuyBusinessAsset}
            year={year}
            keyRate={keyRate}
            currentNews={currentNews}
          />
        )}

        {activeTab === 'banking' && (
          <BankingTab
            cash={cash}
            annualSalary={annualSalary}
            loans={loans}
            onTakeLoan={handleTakeLoan}
            creditCard={creditCard}
            onUseCreditCard={handleUseCreditCard}
            onRepayCreditCard={handleRepayCreditCard}
            debitCard={debitCard}
            onToggleDebitCard={handleToggleDebitCard}
            keyRate={keyRate}
          />
        )}

        {activeTab === 'career' && (
          <CareerTab
            cash={cash}
            character={character}
            annualSalary={annualSalary}
            educationTiers={educationTiers}
            onCompleteEducation={handleCompleteEducation}
            burnoutPenaltyActive={joy < 30}
            flowStateActive={joy >= 85}
          />
        )}

        {activeTab === 'news' && (
          <NewsTab
            currentNews={currentNews}
            inflationRate={inflationRate}
            keyRate={keyRate}
            newsHistory={newsHistory}
            year={year}
            activeCrisis={activeCrisis}
            onTriggerAiNews={handleTriggerAiMacroEvent}
            onTriggerAiGameplayEvent={handleTriggerAiGameplayEvent}
            isGeneratingAi={isGeneratingAiNews}
            autoAiEnabled={autoAiEnabled}
            onToggleAutoAi={() => setAutoAiEnabled((prev) => !prev)}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsTab
            history={history}
            netWorth={netWorth}
            cash={cash}
            stocksValue={stocksValue}
            bondsValue={bondsValue}
            depositsValue={depositsValue}
            cryptoValue={cryptoValue}
            businessValue={businessValue}
            debtTotal={debtTotal}
            totalDividendsEarned={totalDividendsEarned}
            totalCouponsEarned={totalCouponsEarned}
            totalSalaryEarned={totalSalaryEarned}
            currentJoy={joy}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <span className="font-semibold text-slate-700">ФинПуть</span> · Симулятор финансовой жизни и инвестиций
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsRulesOpen(true)}
              className="hover:text-slate-900 transition-colors"
            >
              Справочник правил
            </button>
            <button
              onClick={() => setIsLeaderboardOpen(true)}
              className="hover:text-slate-900 transition-colors"
            >
              Зал славы
            </button>
            <button
              onClick={() => setIsSetupOpen(true)}
              className="hover:text-slate-900 transition-colors"
            >
              Сменить цель
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <TurnSummaryModal
        isOpen={isTurnSummaryOpen}
        onClose={() => setIsTurnSummaryOpen(false)}
        report={lastTurnReport}
        inflationRate={inflationRate}
        currentNews={currentNews}
      />

      <EventModal
        isOpen={isEventModalOpen}
        onClose={() => setIsEventModalOpen(false)}
        onSelectChoice={handleSelectEventChoice}
        event={currentEvent}
        insuranceSavedLoss={eventInsuranceSaved}
      />

      <RulesGuideModal
        isOpen={isRulesOpen}
        onClose={() => setIsRulesOpen(false)}
      />

      <OnboardingTourModal
        isOpen={isTourOpen}
        onClose={() => setIsTourOpen(false)}
      />

      <DownloadModal
        isOpen={isDownloadOpen}
        onClose={() => setIsDownloadOpen(false)}
      />

      <LeaderboardModal
        isOpen={isLeaderboardOpen}
        onClose={() => setIsLeaderboardOpen(false)}
        entries={leaderboard}
        onClearLeaderboard={() => {
          localStorage.removeItem(LEADERBOARD_KEY);
          setLeaderboard([]);
        }}
      />

      <GameOverModal
        isOpen={isGameOverOpen}
        isVictorious={isVictorious}
        failReason={failReason}
        totalCapital={netWorth}
        cashAmount={cash}
        investedAmount={investedAmount}
        finalJoy={joy}
        yearsTaken={year}
        goal={goal}
        mode={gameMode}
        hasUnpaidCreditCard={creditCard.usedAmount > 0}
        onPlayAgain={() => {
          setIsGameOverOpen(false);
          setIsSetupOpen(true);
        }}
        onViewLeaderboard={() => {
          setIsGameOverOpen(false);
          setIsLeaderboardOpen(true);
        }}
      />

      <GameSetupModal
        isOpen={isSetupOpen}
        onStartGame={handleStartGame}
      />
    </div>
  );
}
