import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Initialize GoogleGenAI client with required User-Agent header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Endpoint for AI-generated macroeconomic news and multi-year crises
app.post('/api/generate-news', async (req, res) => {
  try {
    const {
      year = 1,
      inflationRate = 0.08,
      keyRate = 0.12,
      requestedType = 'RANDOM', // 'RANDOM' | 'CRISIS' | 'BOOM' | 'STAGFLATION' | 'TECH'
      requestedDuration, // 1 | 2 | 3
    } = req.body;

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY not configured on server',
        fallback: true,
      });
    }

    const durationInstruction = requestedDuration
      ? `Продолжительность события должна составлять ровно ${requestedDuration} года/лет.`
      : `Выбери случайную продолжительность кризиса или цикла: 1, 2 или 3 года.`;

    const typeInstruction =
      requestedType === 'CRISIS'
        ? 'Сгенерируй острый экономический или финансовый кризис (падение фондового рынка, всплеск инфляции или рост ставки ЦБ).'
        : requestedType === 'BOOM'
        ? 'Сгенерируй мощный экономический бум или сырьевое/технологическое ралли (рост рынка, снижение инфляции, приток инвестиций).'
        : requestedType === 'STAGFLATION'
        ? 'Сгенерируй стагфляцию (высокая инфляция при спаде деловой активности).'
        : requestedType === 'TECH'
        ? 'Сгенерируй технологический прорыв (бум искусственного интеллекта, автоматизации, взлет IT-сектора).'
        : 'Сгенерируй реалистичное макроэкономическое событие для российской экономики (это может быть кризис на 1-3 года, бум, отраслевой шок или реформа).';

    const systemPrompt = `Ты — автономный ИИ-режиссер экономики и финансовых рынков в пошаговой экономической игре «ФинПуть».
Игрок НЕ выбирает наступление кризисов вручную. Ты САМОСТОЯТЕЛЬНО анализируешь ситуацию и непредсказуемо объявляешь макроэкономические события и многолетние циклы!

ПРАВИЛА ПРИНЯТИЯ РЕШЕНИЙ НЕЙРОСЕТЬЮ:
1. В ~35% случаев ты должен НЕОЖИДАННО объявить экономический кризис (cycleType: "CRISIS" или "STAGFLATION") длительностью 1, 2 или 3 года (укажи durationYears: 1, 2 или 3):
   - Банковский кризис ликвидности, санкционный шок, валютный кризис, кризис перепроизводства или обвал фондового рынка.
   - stockMarketMultiplier от 0.65 до 0.82 (падение акций на 18-35%).
   - keyRateDelta от +0.03 до +0.06 (Центробанк экстренно поднимает ставку).
   - inflationDelta от +0.025 до +0.06 (рост инфляции и удорожание жизни).
   - hitSector: обязательно укажи один сектор из списка ниже, который терпит наибольшие убытки.
2. В ~25% случаев ты объявляешь экономический или технологический бум (cycleType: "BOOM" или "TECH_RALLY") длительностью 1 или 2 года:
   - Сырьевое ралли, технологический прорыв в ИИ, господдержка промышленности или рекордный приток инвестиций.
   - stockMarketMultiplier от 1.20 до 1.45 (рост акций на 20-45%).
   - keyRateDelta от -0.01 до -0.03 (смягчение кредитов).
   - favoredSector: сектор-лидер роста.
3. В остальных ~40% случаев — умеренный год или локальное событие (cycleType: "STANDARD", durationYears: 1).

В игре ровно 8 секторов акций:
- IT & ИИ
- Финансы & Финтех
- Нефть & Газ
- Потребительский
- Металлургия
- Электронная коммерция
- Девелопмент
- Биотехнологии

Верни ТОЛЬКО валидный JSON со следующими полями:
{
  "headline": "Краткий и броский заголовок новости (до 60 символов)",
  "summary": "Развернутое описание ситуации, причин и последствий для экономики (2-3 предложения)",
  "durationYears": число 1, 2 или 3,
  "cycleType": "CRISIS" или "BOOM" или "STAGFLATION" или "TECH_RALLY" или "STANDARD",
  "inflationDelta": число изменения инфляции от -0.03 до +0.07,
  "keyRateDelta": число изменения ставки ЦБ от -0.03 до +0.06,
  "stockMarketMultiplier": коэффициент изменения рынка акций от 0.65 до 1.45,
  "cryptoMultiplier": коэффициент криптовалюты от 0.40 до 2.50,
  "favoredSector": название сектора в плюсе (из списка выше, или ""),
  "hitSector": название сектора под ударом (из списка выше, или ""),
  "salaryMultiplier": коэффициент влияния на зарплаты от 0.85 до 1.20,
  "businessMultiplier": коэффициент влияния на прибыль бизнеса от 0.70 до 1.30,
  "gameplayAdvice": "Конкретный совет игроку: какие активы покупать, продавать или избегать"
}`;

    const userPrompt = `Текущий игровой год: ${year}.
Текущая инфляция в стране: ${(inflationRate * 100).toFixed(1)}%.
Текущая ключевая ставка ЦБ: ${(keyRate * 100).toFixed(1)}%.
Сгенерируй новое макроэкономическое событие.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.85,
      },
    });

    const responseText = response.text?.trim() || '{}';
    const parsedData = JSON.parse(responseText);

    const result = {
      id: `ai_macro_${Date.now()}`,
      headline: parsedData.headline || 'Смена экономического цикла',
      summary: parsedData.summary || 'Рынки перестраиваются под влиянием глобальных макроэкономических факторов.',
      durationYears: parsedData.durationYears || 1,
      yearsRemaining: parsedData.durationYears || 1,
      cycleType: parsedData.cycleType || (parsedData.durationYears > 1 ? 'CRISIS' : 'STANDARD'),
      inflationDelta: Number(parsedData.inflationDelta) || 0.01,
      keyRateDelta: Number(parsedData.keyRateDelta) || 0.01,
      gameplayAdvice: parsedData.gameplayAdvice || 'Диверсифицируйте вложения и поддерживайте запас подушки безопасности.',
      isAiGenerated: true,
      marketImpact: {
        stockMarketMultiplier: Number(parsedData.stockMarketMultiplier) || 1.0,
        cryptoMultiplier: Number(parsedData.cryptoMultiplier) || 1.0,
        favoredSector: parsedData.favoredSector || undefined,
        hitSector: parsedData.hitSector || undefined,
        salaryMultiplier: Number(parsedData.salaryMultiplier) || 1.0,
        businessMultiplier: Number(parsedData.businessMultiplier) || 1.0,
      },
    };

    return res.json(result);
  } catch (error) {
    console.error('Error generating AI news:', error);
    return res.status(500).json({
      error: 'Failed to generate AI news',
      details: String(error),
      fallback: true,
    });
  }
});

// Endpoint for AI-generated life and gameplay events
app.post('/api/generate-gameplay-event', async (req, res) => {
  try {
    const {
      characterName = 'Алексей',
      role = 'IT-разработчик',
      year = 1,
      cash = 500000,
      netWorth = 1000000,
      annualSalary = 1200000,
      joy = 70,
      hasCar = false,
      hasApartment = false,
      hasBusiness = false,
      activeCrisisTitle,
    } = req.body;

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY not configured on server',
        fallback: true,
      });
    }

    const contextItems: string[] = [
      `Персонаж: ${characterName} (${role})`,
      `Игровой год: ${year}`,
      `Свободные наличные: ${Math.round(cash).toLocaleString('ru-RU')} ₽`,
      `Капитал: ${Math.round(netWorth).toLocaleString('ru-RU')} ₽`,
      `Годовая зарплата: ${Math.round(annualSalary).toLocaleString('ru-RU')} ₽`,
      `Уровень радости: ${joy}/100`,
      hasCar ? 'Есть собственный автомобиль' : 'Автомобиля нет',
      hasApartment ? 'Есть собственная квартира' : 'Арендует жилье',
      hasBusiness ? 'Владеет действующим бизнесом/активами' : 'Бизнеса нет',
    ];

    if (activeCrisisTitle) {
      contextItems.push(`В стране активен макроэкономический кризис/бум: «${activeCrisisTitle}»`);
    }

    const systemPrompt = `Ты — креативный сценарист и геймдизайнер экономической игры «ФинПуть».
Твоя задача — сгенерировать яркое, реалистичное, сюжетное жизненное или финансовое событие года для игрока на русском языке с учетом его финансового контекста и профессии.

Событие может быть:
- Внезапным шансом или предложением (стартап, фриланс, выгодная сделка, инвестиционный клуб, зарубежная стажировка)
- Форс-мажором (медицинские расходы, поломка авто/техники, ремонт квартиры, налоговая проверка, потеря багажа)
- Личной радостью или семейным событием (свадьба, премия, выигрыш в конкурсе, спортивное достижение)

Правила покрытия страховками:
- Если событие связано со здоровьем/лечением, укажи coveredByInsurance: "HEALTH_DMS"
- Если событие связано с авариями/ремонтом авто (только если у игрока есть авто!), укажи coveredByInsurance: "CAR_CASCO"
- Если событие связано с повреждением жилья/ремонтом дома (только если есть квартира!), укажи coveredByInsurance: "HOME"
- Иначе coveredByInsurance: null

Верни ТОЛЬКО валидный JSON:
{
  "title": "Краткий и броский заголовок (до 45 символов)",
  "description": "Атмосферное описание ситуации от второго лица (2-3 предложения)",
  "cashDelta": число рублей (например -80000 или 120000 или 0),
  "joyDelta": число пунктов радости от -20 до +25,
  "coveredByInsurance": "HEALTH_DMS" или "CAR_CASCO" или "HOME" или null,
  "insuranceAvoidedLoss": число рублей потерь при наличии страховки (или 0),
  "iconType": "good" или "bad" или "neutral",
  "hasChoice": true или false,
  "choices": [
    {
      "id": "option_a",
      "label": "Текст первого выбора (например: Принять предложение)",
      "cashDelta": число,
      "joyDelta": число,
      "description": "Краткое последствие выбора"
    },
    {
      "id": "option_b",
      "label": "Текст второго выбора (например: Отказаться и не рисковать)",
      "cashDelta": число,
      "joyDelta": число,
      "description": "Краткое последствие выбора"
    }
  ]
}`;

    const userPrompt = `Контекст игрока:\n${contextItems.join('\n')}\nСгенерируй новое увлекательное событие года.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.9,
      },
    });

    const responseText = response.text?.trim() || '{}';
    const parsed = JSON.parse(responseText);

    const result = {
      id: `ai_event_${Date.now()}`,
      title: parsed.title || 'Неожиданное событие года',
      description: parsed.description || 'В вашей жизни произошли непредвиденные перемены, повлиявшие на финансы и настроение.',
      cashDelta: Number(parsed.cashDelta) || 0,
      joyDelta: Number(parsed.joyDelta) || 0,
      coveredByInsurance: parsed.coveredByInsurance || undefined,
      insuranceAvoidedLoss: Number(parsed.insuranceAvoidedLoss) || Math.abs(Number(parsed.cashDelta) || 0),
      iconType: (parsed.iconType === 'good' || parsed.iconType === 'bad') ? parsed.iconType : 'neutral',
      isAiGenerated: true,
      choices: Array.isArray(parsed.choices) && parsed.choices.length >= 2 ? parsed.choices : undefined,
    };

    return res.json(result);
  } catch (error) {
    console.error('Error generating AI gameplay event:', error);
    return res.status(500).json({
      error: 'Failed to generate AI gameplay event',
      details: String(error),
      fallback: true,
    });
  }
});

async function start() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    // In dev, mount Vite middleware
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve built files
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server started on http://0.0.0.0:${PORT}`);
  });
}

start();
